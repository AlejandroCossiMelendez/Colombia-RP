SUPERMAN_FLY_DATA_KEY = "superman:flying"
SUPERMAN_TAKE_OFF_DATA_KEY = "superman:takingOff"