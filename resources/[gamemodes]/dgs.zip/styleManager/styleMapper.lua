--Add your style map here
--Name = "Path",
--For Example:
--Default="Default",
use="Default", --This determines which style to use on DGS startup.
