--if fileExists("sourceC.lua") then
	--fileDelete("sourceC.lua")
--end

local sx,sy = guiGetScreenSize()

local show = false
local textShowing = false
setElementData(localPlayer, "char:check", false)

local designation = 1
local status = "Kikapcsolva"
local soundElementsOutside = { }
local musicTable = {
 {"http://108.61.30.179:4010/;stream", "HOT 108 JAMZ"},
 {"http://149.11.65.228:3690/Q_DANCE_SC", "Q-DANCE"},
 {"http://stream.composeit.hu:8100/sunshine", "Sunshine FM"},
 {"https://usradio.stream.laut.fm/usradio", "US Radio"},
 {"http://185.52.127.170/de/33017/mp3_128.mp3", "ENERGY R&B"},
 {"http://149.56.175.167:5461/;", "Hip-Hop Request"},
 {"http://air.radiorecord.ru:8102/yo_320", "Yo 320 FM"},
 {"http://s10.voscast.com:8872/;", "Wu Tang World"},
 {"https://topradio-de-hz-fal-stream05-cluster01.radiohost.de/kissfm-rnb_mp3-128", "AXR Hot Beatz"},
 {"http://rautemusik-de-hz-fal-stream13.radiohost.de/charthits", "ChartHits"},
 {"http://ais-sa2.cdnstream1.com/1984_128.mp3", "Awesome R&B"},
 {"http://stream5.radio1.hu/high.mp3", "Rádió 1"},
 {"http://mr-stream.mediaconnect.hu/4738/mr2.mp3", "Petőfi Rádió"},
 {"http://mediagw.e-tiger.net/stream/coolfm#.mp3?time=1476018047900", "Cool FM"},
 {"http://gr02.cdnstream.com:8302/;stream.nsv", "International Melodies"},
 {"http://hydra.cdnstream.com/1540_128", "Miscellaneous R&B"},
 {"http://air.radiorecord.ru:8102/rus_320", "Russian Mix"},
 {"http://online.kissfm.ua/KissFM", "Underworld"},
 {"http://air.radiorecord.ru:8102/chil_320", "Radio Chill-Out"},
 {"http://ice1.somafm.com/thetrip-128-mp3", "The Trip Progressive house/trance"},
 {"https://dancewave.online/dance.mp3?time=1591685102865", "Dance Wave"},
 {"https://sr11.inmystream.it:8026/stream", "Strudel ON"},
 {"https://kathy.torontocast.com:1095/stream", "UK Top 40"},
 {"https://radionationfm.stream.laut.fm/radionationfm?t302=2020-06-12_11-40-52&uuid=40ac99de-c352-406e-a6eb-4e8751cb9c10", "Radionation"},
 {"https://topradio-de-hz-fal-stream05-cluster01.radiohost.de/kissfm-rnb_mp3-128", "Master Classic"},
 {"http://gr02.cdnstream.com:8172/;?cb=899958.mp3&type=.mp3", "HIP-HOP Shout"},
 {"http://185.52.127.157/de/33041/mp3_128.mp3", "Energy Rap US"},
 {"http://198.245.62.16:8066/;", "Atlanta Hot"},
 {"https://cast.mgtradio.net/radio/8010/radio.aac", "MGT Down"},
 {"http://stream01.my105.ch/my105oldschool.mp3", "105 Oldschool"},
 {"https://mp3.ffh.de/ffhchannels/hqxmas.aac", "Christmas Eve"},
 {"http://listen.livestreamingservice.com/181-halloween_128k.mp3", "Halloween"},
 {"http://onair.krone.at/kronehit-hd.mp3", "Kronehit"},
 {"http://online.kissfm.ua/KissFM_Deep", "Deepen"},
 {"http://online.kissfm.ua/KissFM_Trendz", "Long Trendz"},
 {"http://stream.mercyradio.eu/jimmy.mp3?25468582", "A Király rádiója"},
 {"http://stream.radio.co/s40d910a74/listen?token=7b2ba94b17ce01b68c38d5dcfade83c1%2F13afe30d", "Front Porch"},
 {"https://sr11.inmystream.it:8026/stream", "iHeart Radio"},
 {"http://67.212.165.106:8290/stream", "UVC Aqua"},
 {"http://hydra.cdnstream.com/1538_backup?listenerId=567d460772867c52343992f08bb29958&aw_0_1st.playerid=esPlayer&aw_0_1st.skey=1591800896", "Easter"},
 {"http://hydra.cdnstream.com/1540_128?listenerId=567d460772867c52343992f08bb29958&aw_0_1st.playerid=esPlayer&aw_0_1st.skey=1591800904", "Friday Cost"},
 {"http://crystalout.surfernetwork.com:8001/KKSI_MP3", "Siccness"},
 {"https://tntradio.hostingradio.ru:8027/hhr128.mp3?radiostatistica=onlineradiobox.com", "TNT"},
 {"http://ample-04.radiojar.com/q8yghdvnu1duv?rj-ttl=5&rj-tok=AAABcp7jq7kA5HZZGHpn_mBeJg", "Rapcore"},
 {"https://str2b.openstream.co/587", "Powerjammerz"},
 {"https://bestof2015.stream.laut.fm/bestof2015?ref=radiode&t302=2020-06-10_17-36-53&uuid=22851130-62aa-475f-97b2-f39708440285", "Best of H!TS"},
 {"https://ais-sa2.cdnstream1.com/1988_64.aac", "All Saints Street"},
 {"https://stream.radio3.no/radiobardufoss192", "Wild Soul Child"},
 {"https://gene-wr11.ice.infomaniak.ch/gene-wr11.mp3", "Generations Slow Jamz"},
 {"http://gr01.cdnstream.com:8270/;", "Got it"},
 {"https://cxfm.stream.laut.fm/cxfm", "CashX"},
 {"https://fluxfm.hoerradar.de/flux-rnb-mp3-mq", "Flux HOT R&B"},
 {"https://22353.live.streamtheworld.com/RADIO538AAC_SC", "The World – HipHop/R&B"},
 {"https://stream.musicone.fm/musicone.mp3", "Core FM"},
 {"https://jivn.stream.laut.fm/jivn", "Progressive Hits"},
 {"http://hemnos.cdnstream.com/1674_128", "Classic Joints"},
 {"https://hiphop-forever.stream.laut.fm/hiphop-forever", "Hip-Hop Forever"},
 {"http://hydra.cdnstream.com/1537_128", "Greatest Different"},
 {"http://192.211.51.158:5485/;stream.nsv", "Flex FM"},
 {"http://kea.cdnstream.com/1892_128", "Classic Rock"},
 {"https://rocknrolle.stream.laut.fm/rocknrolle", "Roll"},
 {"https://stream.radio.co/sfc32ef5c7/listen", "steady"},
 {"https://edge-ads-04-gos1.sharp-stream.com/kissfm1006hq.mp3?", "endless party"},
 {"https://xvhradio.stream.laut.fm/xvhradio?t302=2020-06-21_20-34-21&uuid=1c3f040b-6b1e-4bf1-adbc-efcf979033e6", "white dove"},
 {"http://195.150.20.242:8000/rmf_2 ", "galaxy trip"},
 {"https://experienceradio.dynamit.host:1045/stream", "experience"},
 {"http://158.69.4.171:8066/stream", "The Cayman Islands"},
 {"http://185.126.217.8:9358/;stream.nsv", "Give Air"},
 {"http://77.68.21.190:8000/;", "Intense Waves"},
 {"https://fluxfm.hoerradar.de/flux-boomclassics-mp3-mq?", "Boom West"},
 {"http://hydra.cdnstream.com/1541_128", "Smooth R&B"},
 {"http://live.sunfm.com.ua:8048/live", "sun."},
 {"http://powershots.skglobe.net/;", "Powershots Global"},
 {"https://hitmixoesterreich.stream.laut.fm/hitmix_oesterreich?t302=2020-06-12_10-44-18&uuid=178ce07b-639a-4f62-96fa-97edc98e33a6", "Hitmix"},
 {"https://fluxfm.hoerradar.de/flux-boomclassics-mp3-mq?", "Missed Calls"},
 {"http://hyades.shoutca.st:8627/;", "The Lake"},
 {"http://46.20.3.246/stream/50/", "Lowrider Cut"},
 {"https://hestia2.cdnstream.com/1668_128", "Canada Flowz"},
 {"https://node-18.zeno.fm/k1cra0edtqzuv?rj-ttl=5&rj-tok=AAABctqsKxEARJ4YMebgLF85CQ", "Dallas Bachata"},
 {"http://184.154.206.204:8000/1", "WWMR Chicago"},
 {"https://webradio.antennevorarlberg.at/workout-hits", "Workout Time"},
 {"https://sonic.mallocohosting.cl/8042/stream", "Infinity Splits"},
 {"https://chartradio-germany.stream.laut.fm/chartradio-germany", "Gauge Charts"},
 {"https://node-08.zeno.fm/2qh7y5wak0quv?rj-ttl=5&rj-tok=AAABcqgPYYQA2NCRhiRUOu7Uzw", "Black Tower"},
 {"http://live.uafm.org:9001/uafm", "Hold Empire"},
 {"http://wssgd.gdsinfo.com:8200/;stream.mp3", "Balaton"},
 {"https://ice07.fluidstream.net/lovefm.mp3?FLID=3", "Love Hits"},
 {"https://streams.radio.co/s822d45399/listen", "Power 909"},
 {"http://198.245.62.16:8156/;", "KC Hot"},
 {"https://topradio-de-hz-fal-stream08-cluster01.radiohost.de/kissfm-sextime_128", "Beverly Hills explosive"},
 {"http://radio.music-madness.net:8000/music_madness_medium", "Medium Circles"},
 {"https://radiocomucosa.turadioonline.xyz/stream", "Grape Jelly"},
 {"http://stream15.top-ix.org/radiojukebox", "Beatbox"},
 {"https://nr8.newradio.it/proxy/ristoran?mp=/stream", "Ristorante Convento"},
 {"http://streaming01.zfast.co.uk:8178/;stream.mp3", "Lilt Taster"},
 {"https://streaming.galaxywebsolutions.com:9016/stream", "Brave UK"},
 {"http://ice66.securenetsystems.net/WINR", "Crush Plane"},
 {"https://streamer.radio.co/sd80120679/listen", "Amazing Season"},
 {"http://streaming.hotmixradio.fr/hotmixradio-game-64.mp3?from=tunein", "Spreadin' Stones"},
 {"http://173.198.222.86:9020/;", "Alternative Clouds"},
 {"http://983radio.ddns.net:8002/;", "Relative Hits"},
 {"https://thebestof2016.stream.laut.fm/thebestof2016", "Melodies of 2016"},
 {"https://hitsvonheute.stream.laut.fm/hitsvonheute", "Student"},
 {"https://s2.radio.co/sa32acf263/listen", "Roomy Tunes"},
 {"http://stream.readyformed.com:8000/wey2", "The Valley"},
 {"http://golive.onestreaming.com/athensparty", "Athens Party"},
 {"http://ice.onestreaming.com/athenspartyrnb", "R&B Nightclub"},
 {"http://listen.one.hiphop/live.mp3", "OneLoveHipHop"},
 {"http://usa8.fastcast4u.com:5535/stream?", "YUL-Drunk"},
 {"https://strmreg.1.fm/top40ballads_mobile_mp3", "USA – Top 40 Ballads"},
 {"https://hitradioeins.stream.laut.fm/hitradio_eins?t302=2020-06-19_12-10-40&uuid=d31946d4-6a8d-42b1-9500-5f29cb1e4116", "Pretty Turns"},
 {"https://freeuk5.listen2myradio.com/live.mp3?typeportmount=s2_27550_stream_637971279", "Radio Bizonio"},
 {"http://onair15.xdevel.com:7098/;", "Long Travel"},
 {"http://radio.eurotruckradio.co.uk:8000/stream", "Euro Finals"},
 {"http://19013.live.streamtheworld.com/SP_R2320766_SC", "Chillest Ibiza"},
 {"http://198.245.62.16:8186/;", "Millwaukee St."},
 {"http://172.82.141.139:7416/;stream.nsv", "GoalsLoop"},
 {"http://ca8.rcast.net:4046/stream", "Hot Rocks"},
 {"http://198.245.62.16:8042/;", "Tonight"},
 {"https://radio-stream-2.obozrevatel.com/RnB128.mp3", "Obozrevatel"},
 {"http://node-06.zeno.fm/f142ha9kxtzuv?rj-ttl=5&rj-tok=AAABcqdFQaUAPg4f7qPIpjqS5g", "Complex"},
 {"https://fluxfm.hoerradar.de/flux-xjazz-mp3-hq", "Flux Jazz"},
 {"https://radiopro.com.uy/radio/8020/pyg", "PYG Requestbar"},
 {"http://198.245.62.16:8096/;", "Canadian Hot"},
 {"https://stream.standfy.es/radio/8000/standfy_fm", "Standy"},
 {"http://node-19.zeno.fm/cpvysp4m4ceuv?rj-ttl=5&rj-tok=AAABcqdUa-MAW2FE4Fy5yuCTnA", "World H!TS"},
 {"http://node-21.zeno.fm/t28n1qv7z5quv?rj-ttl=5&rj-tok=AAABcqdWTkMAPC7YFbg-0olm9A", "Fuerza"},
 {"https://radio4u.stream.laut.fm/radio4u", "Radio4U"},
 {"https://invasionradio.stream.laut.fm/invasionradio", "Invasion"},
 {"https://chiemgaufm.stream.laut.fm/chiemgaufm", "Chiemgau"},
 {"https://generations-rnb-gold.ice.infomaniak.ch/generations-rnb-gold.mp3", "Next Generation Leaders"},
 {"https://listen.radioking.com/radio/75868/stream/113899", "Disco Hits"},
 {"https://fluxfm.hoerradar.de/flux-event01-mp3-mq?", "80s chill-out"},
 {"https://stream.laut.fm/nasty", "Perished Area"},
 {"https://daniel.torontocast.com:3005/stream", "Northcast"},
 {"https://radiofriendssticktogether.stream.laut.fm/radiofriendssticktogether", "Sticky Notes"},
 {"https://node-32.zeno.fm/pzdkunbxaseuv?rj-ttl=5&rj-tok=AAABcqflOMcAneV6lu4S0q74pA", "Lapu-Lapu Vicinity"},
 {"https://node-27.zeno.fm/287d25k0ahruv?rj-ttl=5&rj-tok=AAABcskIhbQAvC8nOV7nkGyoRg", "Pilipino R&B"},
 {"http://185.52.127.172/de/56852/mp3_128.mp3", "Fest"},
 {"https://mcholm.stream.laut.fm/mcholm?t302=2020-06-12_11-42-29&uuid=d103e1ad-027d-4b56-8beb-1073d82ab2ac", "Deichkind"},
 {"https://mediagw.e-tiger.net/stream/zc11?ver=536855", "CoolHits"},
 {"https://radio-stream-0.obozrevatel.com/top-100-kiev128.mp3", "Small Winner"}, 
 {"https://node-26.zeno.fm/wktedehxaseuv?rj-ttl=5&rj-tok=AAABcqf8HSUATtDZRh2PtPnuKw", "Boracay White Beach"},
 {"https://securestreams.servers58.com:8194/stream", "HD Variety"},
 {"https://bigrradio.cdnstream1.com/5106_128", "2000 FM – Top 100"},
 {"http://137.74.85.85:8000/spacefm.mp3", "Space FM"},
 {"http://airtime.radiox.online:8000/hq", "Time-X"},
 {"http://radio.konakovofm.ru:8000/live", "Exercises"},
 {"https://stream.vyshka24.ru/128", "Sverdlovsk Dubstep"},
 {"http://node-19.zeno.fm/cpvysp4m4ceuv?rj-ttl=5&rj-tok=AAABcqgUXc8AzOFaC8O_bCGL5Q", "Champion Chunking"},
 {"https://ais-sa1.streamon.fm/7331_48k.aac", "River"},
 {"https://sonic.portalfoxmix.cl:7226/;", "Sinergia"},
 {"http://stream.specific.dk/SR", "Specefic"},
 {"http://n08.radiojar.com/r15cta1gfkeuv?rj-ttl=5&rj-tok=AAABcqgjgcoAxkatjRbEf5F1og", "Rewind Legends"},
 {"http://198.245.62.16:8138/;", "Up Melodies"},
 {"http://198.245.62.16:8078/;", "Baltimore"},
 {"https://0n-black.radionetz.de/0n-black.mp3", "Sharp Blade"},
 {"http://198.245.62.16:8234/;", "Coming High"},
 {"http://s4.streammonster.com:8452/stream", "Smack-em"},
 {"https://server.radiohop.ru/radio/8000/radio.mp3", "Labrinth Lounge"},
 {"https://nineplusonescher.stream.laut.fm/nineplusonescher?t302=2020-06-13_08-54-02&uuid=45efd239-aa76-4341-bc85-0fea5213f8ab", "Nineplusonesche"},
 {"https://streamingv2.shoutcast.com/adam-fm-radio", "Chronic"},
 {"https://allzic08.ice.infomaniak.ch/allzic10.mp3", "Around Express"},
 {"http://198.245.62.16:8174/;", "Louisville Dance"},
 {"http://213.136.92.8:8038/;", "American Music Awards"},
 {"https://mshit-radio.stream.laut.fm/mshit-radio", "Fast Track Lane"},
 {"https://ais-sa1.streamon.fm/7241_64k.aac?starttime=1548057163", "Blend pleasure"},
 {"https://listen.radioking.com/radio/463/stream/116740", "Palace Disco"},
 {"https://edge2-b.exa.live365.net/a06964", "Viva Novelty"},
 {"http://roosevelt.backbonebroadcast.com:8081/roosevelt", "WRBC – The Blaze"},
 {"http://198.245.62.16:8228/;", "Oklahoma"},
 {"https://radiojm24mix.stream.laut.fm/radiojm24mix", "Audio JM 24"},
 {"https://listen.radioking.com/radio/72040/stream/109951", "Happiness Oise"},
 {"http://ramon1.radioca.st/hitzc", "HitzConnect"},
 {"https://dublab.out.airtime.pro/dublab_b", "Dublab"},
 {"https://splashmcfm.stream.laut.fm/splashmcfm", "Splash FM"},
 {"http://200.54.198.205:8000/listen", "Magnificent"},
 {"http://rautemusik-de-hz-fal-stream11.radiohost.de/jam", "/// Hip-Hop /// FUNK /// R'n'B ///"},
 {"https://s2.radio.co/s7bb3ee4d9/listen", "do-all Casette"},
 {"https://cast.sistemahost.es:3495/stream", "Trap HQ"},
 {"https://s35.derstream.net/fantasyblack.mp3", "Studio JAMZ"},
 {"https://s37.myradiostream.com/14498/;", "Pulse"},
 {"http://136.243.111.216/jam", "Rearwards Jam"},
 {"http://198.245.62.16:8108/;", "Cincinnati fizzy"},
 {"https://edge2-b.exa.live365.net/a40412", "The Vibelyfe"},
 {"https://rs10-krk1-orange.rmfstream.pl/MAXXX2014", "RMF – Hip-Hop House"},
 {"https://radio.dline-media.com/tvsradio", "TBC Hot"},
 {"https://radio-stream-1.obozrevatel.com/hiphopandrnb128.mp3", "DOG"},
 {"https://ndr-edge-10c1-dus-dtag-cdn.cast.addradio.de/ndr/ndrblue/live/mp3/128/stream.mp3", "NDR Blue"},
 {"http://dubstep-light.info:8000/dubsteplight-96.mp3", "Dubstep Light"},
 {"http://stream3.virtualisan.net:8000/freshmobil.aac", "Hit Maps"},
 {"http://uzivo4.radiopingvin.com:8187/strani1", "Pingvin WORLD"},
 {"https://splashmcfm.stream.laut.fm/splashmcfm", "Splash FM"},
 {"http://79.120.77.11:8002/rnb", "Heart Caprice"},
 {"http://178.32.136.9:9099/;stream/1", "Nova Ions"},
 {"https://radio.kamchatkalive.ru:8103/chillout", "downtempo"},
 {"https://supremeeveryday.stream.laut.fm/supreme_everyday?t302=2020-06-12_16-15-32&uuid=33074791-21f9-43ad-a25a-786ec4c6b8b8", "Everyday beginning"},
 {"http://node-04.zeno.fm/dgvr6zvwxwzuv?rj-ttl=5&rj-tok=AAABcqwRDNMAOM8tZ4_-PmpdkA", "Contemporanea achievable"},
 {"https://allzic34.ice.infomaniak.ch/allzic34.mp3", "Tricks Lovers"},
 {"https://mcholm.stream.laut.fm/mcholm?t302=2020-06-13_06-57-13&uuid=aaaa8dcf-6b94-425c-97ca-7105f7514348", "Stockholm"},
 {"https://sr11.inmystream.it:8026/stream", "Boston flames"},
 {"http://icepool.silvacast.com/DEFJAY.mp3", "Defjay"},
 {"http://proxima.shoutca.st:8901/stream;", "Iconic Extra"},
 {"https://streamingv2.shoutcast.com/arastro", "Arasto"},
 {"https://n03.radiojar.com/eyrdpmzyzd5tv", "Boombox Hip-Hop"},
 {"https://radiodjfm.stream.laut.fm/radiodjfm", "Alternative Changes"},
 {"http://rs4.radiostreamer.com:8390/;", "RealHipHopUncut"},
 {"http://47.203.191.233:8000/stream/3/;", "Jungle Vague"},
 {"http://listen.one.hiphop/live.mp3", "Love Hip-Hop & Oldschool"},
 {"https://nineplusonescher.stream.laut.fm/nineplusonescher?t302=2020-06-13_07-40-07&uuid=bc4687d4-77f2-4027-849a-a96d503bc66a", "Demon Cemetery"},
 {"https://montecarlo.hostingradio.ru/montecarlo96.aacp", "Monte Carlo Romantic"},
 {"https://johnfmradio.stream.laut.fm/johnfmradio", "Blooming Hits"},
 {"http://stream.funradio.sk:8000/fun128.mp3", "Fun & 80s Pop"},
 {"http://node-24.zeno.fm/v5vh079bhhruv?rj-ttl=5&rj-tok=AAABcqxVfckAyHqY9iNJNYX4AQ", "Flash FM"},
 {"https://streams.radio.co/s255233729/listen", "MizFitz FM"},
 {"https://zaycevfm.cdnvideo.ru/ZaycevFM_rnb_256.mp3", "Zaycev FM"},
 {"http://piratenstreams.nl:8008/stream", "AMW HIPHOP"},
 {"https://securestreams.servers58.com:8194/stream", "Scooter"},
 {"http://node-31.zeno.fm/rv09a1yea9quv?rj-ttl=5&rj-tok=AAABcqyNwi8AWDBdjENx_i2laA", "MX Afrobeats"},
 {"http://mediaserv33.live-streams.nl:8022/stream", "Wicked! FM"},
 {"https://gtlive.stream.laut.fm/gtlive", "80s House"},
 {"https://n07.radiojar.com/p86v7rqxm8quv?rj-ttl=5&rj-tok=AAABcrM2Lj0AxD4Df_0ReUYDZg", "Out Jar"},
 {"https://streaming.radio.co/sbba10f75f/listen", "Dancehall"},
 {"https://youngexpressradio.stream.laut.fm/youngexpressradio", "Trance Express"},
 {"https://delta.hoerradar.de/deltaradio-hiphop-mp3-mq?sABC=5rr47ss7%230%23osnr3onq6oqo6n0529066qor5767rpp5%23bayvarenqvbobk&=&amsparams=playerid:onlineradiobox;skey:1592033271", "Delta shy"},
 {"https://streamer.radio.co/sb9163bff2/listen", "say say • soulful hip-hop"},
 {"http://emgregion.hostingradio.ru:8064/moscow.retrofm.mp3", "Moscow Retro"},
 {"https://mediagw.e-tiger.net/stream/krehq?1469960967778.mp3", "Cool XRE"},
 {"http://ice.onestreaming.com/athenspartyrnb", "Athens Party R'n'B"},
 {"https://s35.derstream.net/fantasyblack.mp3", "Fantasy Black"},
 {"https://node-01.zeno.fm/s3wdt380f9duv?rj-ttl=5&rj-tok=AAABcq2Fi8cAFMF65Lg9OwSHoQ", "South Hirondelle"},
 {"https://streamingv2.shoutcast.com/RJM-radio", "RJM POP Hits"},
 {"https://googeradio.dyndns-free.com/listen", "DYN – Variety"},
 {"http://radio.enigmatic.su:8170/radio", "Engimatic Senses"},
 {"https://ssl-radyo.yayin.com.tr:5898/;stream.nsv", "Fuses"},
 {"https://rswr.radioca.st/stream", "Unknown Reggaeton"},
 {"http://stream.mjoy.ua:8000/radio-412", "enjoy at night"},
 {"https://2016.stream.laut.fm/2016", "Figured Charts"},
 {"https://node-13.zeno.fm/gqw62kfvbrruv?rj-ttl=5&rj-tok=AAABcskGnS8AMlTQf2BgP3vY6w", "Actuality FM"},
 {"https://17443.live.streamtheworld.com/WVBWFMAAC_SC", "Outcome"},
 {"http://173.193.205.96:9087/stream", "Texas Party"},
 {"https://stream.radio.co/s4d09e922b/listen", "Rhode Island Vogue"},
 {"https://20673.live.streamtheworld.com/MONEY_893AAC.aac", "Singapore Finance"},
 {"http://192.99.34.205:8147/stream", "Mexico"},
 {"https://anzilistix.stream.laut.fm/anzilistix?t302=2020-06-13_16-26-10&uuid=83a2f815-9fb7-4eee-88ba-a9dcc4a4d09a", "Anzilistix"},
 {"https://streamingv2.shoutcast.com/arastro", "Arastro Workin'"},
 {"http://185.242.180.227:8000/mp3", "Libera Tutti"},
 {"http://node-23.zeno.fm/r9zhnr7bzuquv?rj-ttl=5&rj-tok=AAABcq4kFKQASQQ5F_frD6eknA", "Play FM"},
 {"http://192.227.85.169:4016/stream", "Orange Port"},
 {"https://listen.jetstreamradio.com:8000/autodj", "Dance Jet"},
 {"http://188.40.32.140:8295/stream/;", "Storm"},
 {"http://ample-05.radiojar.com/92as3vsdfwzuv?rj-ttl=5&rj-tok=AAABcq5FdBoA-mKxi5Ojl890Mg", "SHQ Melody"},
 {"https://ice4.abradio.cz/dance128.mp3", "Club Hits"},
 {"https://hazel.torontocast.com:1885/stream", "Preferable Strainer"},
 {"http://stream.lepesradio.hu:4000/live.mp3", "Early Appropriate"},
 {"https://grittlefm.stream.laut.fm/grittlefm", "Grittle Pop Hits"},
 {"https://barbaradio.hoerradar.de/barbaradio-bumsmusik-mp3-hq", "KnickKnack"},
 {"https://aod.planetradio.co.uk/kiss-jams/20180213170156.mp3", "Jamz Garage"},
 {"http://servers58.com:9840/;stream.nsv", "Pop Shuffle"},
 {"https://ssl3.server89.com:9336/;stream.nsv", "Voice & Dance"},
 {"http://node-12.zeno.fm/7w5v3h5sfnzuv?rj-ttl=5&rj-tok=AAABcrGwZQEAiADcXHXe-2DZLw", "100000 tracks"},
 {"http://198.245.62.16:8198/;", "Mississippi, Dt"},
 {"https://113fm.cdnstream1.com/1780_128", "2K's Top 40 Hits"},
 {"https://jay016.stream.laut.fm/jay016", "Jay016"},
 {"http://sc59.lon.llnw.net/stream/bbcmedia_radio1_mf_p", "BBC Radio 1"},
 {"http://node-29.zeno.fm/9yfsurcmqrquv?rj-ttl=5&rj-tok=AAABcrI56EoAlX0gk74Cv68ZvA", "509 Freestyle"},
 {"http://109.169.23.22:31695/;stream.nsv", "AJ Production Rock, 00s, 80s, 90s"},
 {"https://1000-indietracks.stream.laut.fm/1000-indietracks?t302=2020-06-14_12-46-01&uuid=91843c3f-e5d6-4d80-b2db-21fe8a59159b", "1000 Indietracks"},
 {"https://stream.laut.fm/1nice", "VISANIX"},
 {"https://str2b.openstream.co/1632", "AcsCCN Music Worldwide"},
 {"https://edge2-a.exa.live365.net/a95865", "Reggae St."},
 {"https://servidor20-1.brlogic.com:9268/live", "Zero"},
 {"http://46.20.3.246/stream/51/", "Beach House"},
 {"https://node-28.zeno.fm/key2pg77eyduv?rj-ttl=5&rj-tok=AAABctWyhCUA76aiazh2el24lg", "Stereo Lime"},
 {"http://188.26.110.59:8000/terra.mp3", "Terra"},
 {"https://magicradio.ice.infomaniak.ch/magicradio-high.mp3", "Analogue Magic"},
 {"http://shout2.lunabroadcasting.net:7074/;stream.nsv", "Quiet Storm"},
 {"http://node-25.zeno.fm/v64run131mzuv?rj-ttl=5&rj-tok=AAABcrLbnG0A9DtQQAoVuuae8w", "Pop Lite"},
 {"http://daoneradio.primcast.com:5698/;", "Dade Hip-Hop Hits"},
 {"https://energylove.ice.infomaniak.ch/energylove-high.mp3", "LoveHigh"},
 {"https://streamer.radio.co/s56cfe76d8/listen", "Classic Hot"},
 {"http://whatradio.macchiatomedia.org:9119/;stream.nsv", "WHAT'S HAPPENING ?"},
 {"https://keinradio.stream.laut.fm/keinradio", "KeinRadio"},
 {"http://107.155.111.170:8070/;stream.nsv", "Movin' R&B"},
 {"https://icecast.omroep.nl/funx-hiphop-sb-mp3", "FunX HipHop"},
 {"https://netzperlentaucher.stream.laut.fm/netzperlentaucher", "Taucher"},
 {"http://stream.rookeryradio.com:8088/live", "Rookery"},
 {"http://151.80.97.38:8246/stream.mp3", "Club California"},
 {"http://partyradio.zapto.org:9964/;", "Fireworks & New Season"},
 {"http://198.245.62.16:8252/;", "Portland Plays"},
 {"https://anzilistix.stream.laut.fm/anzilistix?t302=2020-06-14_22-51-06&uuid=08ddba1f-1558-435e-8b50-d4f0d02674ff", "Anzilistix"},
 {"https://joge.stream.laut.fm/joge", "Joge"},
 {"https://time.stream.laut.fm/time", "Interest Rate"},
 {"http://hts02.kshost.com.br:10064/live", "More at Once"},
 {"https://strmreg.1.fm/moviesoundtracks_mobile_mp3", "Movie Soundtracks"},
 {"http://87.118.126.229:8585/;600693905645779stream.nsv", "eclectic soundexpress"},
 {"https://21273.live.streamtheworld.com/WEB09_AAC.aac", "SLAM!"},
 {"https://mana-mana.stream.laut.fm/mana-mana", "MANA-MANA"},
 {"https://allzic53.ice.infomaniak.ch/allzic53.mp3", "Allzic – Take it easy"},
 {"https://str2.openstream.co/406", "Voltingurban"},
 {"https://trauerradio.stream.laut.fm/trauerradio", "Trauer"},
 {"https://bestof2014.stream.laut.fm/bestof2014", "Best Beat Feast of 2014"},
 {"https://vaterstettenfm.stream.laut.fm/vaterstettenfm?t302=2020-06-16_09-52-48&uuid=929c305a-43ec-4e1c-8a1b-9514f74573d4", "Vaterstetten FM"},
 {"https://stream1.intronic.nl/citymusic", "CityMusic"},
 {"http://naxidigital128.kbcnet.rs:8120/;", "Naxi R&B"},
 {"http://server142.radiochoice.net:8080/1006_a0hot9564k?type=.mp3", "Omnifarious"},
 {"https://sweet.stream.laut.fm/sweet", "Sweet Cave"},
 {"https://listen.radioking.com/radio/81865/stream/161119", "Redline Aerial"},
 {"http://cmr-hosting.com:8020/;stream.nsv", "CMR – Project"},
 {"http://kea.cdnstream.com/1705_128", "Arapaho Tent"},
 {"http://184.154.45.106:8457/stream", "Radiocun"},
 {"http://s18.myradiostream.com:9676/;stream.nsv", "NonStopOldies"},
 {"http://s4.radioboss.fm:8101/stream", "Route"},
 {"https://17263.live.streamtheworld.com/WRKYAAC_SC", "Altoona's Rock"},
 {"http://streaming07.hstbr.net:8008/live?1495643670532", "Macavi FM"},
 {"http://stream.gaga.fm/", "Dance GaGa"},
 {"https://dw19design.stream.laut.fm/dw19design", "DW19 Design"},
 {"https://19013.live.streamtheworld.com/SP_R2075880_SC", "Coca-Cola FM"},
 {"http://188.40.109.122:8000/ices1", "Luxury Lounge"},
 {"https://xerife-81-fm.stream.laut.fm/xerife-81-fm?t302=2020-06-16_19-02-06&uuid=ea7bb552-a810-4d74-8158-d6bf97553411", "Xerife-81 FM"},
 {"https://edge-baueral-08-cr.sharp-stream.com/gem106.mp3", "Gem 106"},
 {"http://ic.phazern.com.au:8000/PHAZEFM-High", "Phaze FM"},
 {"https://hapes-traumexpress.stream.laut.fm/hapes-traumexpress", "HAPES-TRAUMEXPRESS"},
 {"https://streaming.radio.co:80/se814bcec1/listen", "Work FM"},
 {"https://ample-04.radiojar.com/y47fsua10heuv?rj-ttl=5&rj-tok=AAABcsEJ3tUA5boMTcN2gfGLOQ", "Livingstone College"},
 {"https://alpha-musics.stream.laut.fm/alpha-musics?t302=2020-06-17_09-08-25&uuid=46305255-abed-4e5d-bfed-58c63933d17d", "Music Singles"},
 {"https://centraldance.ice.infomaniak.ch/centraldance-128.mp3", "Central Dance"},
 {"http://5.63.151.52:8035/;", "Generation Years"},
 {"https://a2.radioheart.ru:8009/hbg", "Radio Go"},
 {"http://51.255.104.137:8099/stream", "Smash"},
 {"http://onair11.xdevel.com:8170/;", "Radop Vela"},
 {"https://icecast51.cloudcast.media/stream21", "Virtual 21"},
 {"https://radiosummernight.stream.laut.fm/radiosummernight?t302=2020-06-17_16-11-52&uuid=1d8c3fa4-d51c-4caa-a8df-cb3d1ed9ad3b", "Summernight"},
 {"https://christmasradio24.stream.laut.fm/christmasradio24", "Christmas 24"},
 {"https://mp3.ffh.de/ffhchannels/hqxmas.aac", "Christmas Trees"},
 {"https://radio9.stream.laut.fm/radio9?t302=2020-06-17_18-05-57&uuid=ce9c27e3-b04a-48d2-be20-cd3fa400db37", "Radio 9"},
 {"https://node-04.zeno.fm/8b8h880erwzuv?rj-ttl=5&rj-tok=AAABcsXzuoQAStGKfbFA7wa35Q", "Anzo Pains"},
 {"https://node-29.zeno.fm/knwytnm8bnzuv?rj-ttl=5&rj-tok=AAABcsX1qwYAqXj4ZFFjhnnsfg", "Kalmazoo"},
 {"https://proxy.live-streams.nl/paprikatastyradio", "Paprika Tasty Radio"},
 {"https://generations-2000.ice.infomaniak.ch/generations-2000.aac", "2000 Generations"},
 {"http://149.56.134.163:9986/;", "Smart Studio"},
 {"https://streamer.radio.co/s5af29b339/listen", "Bailiwick 00s & Today"},
 {"http://s02.radio-tochka.com:4130/radio", "Gathering Vibe"},
 {"https://listen.radioking.com/radio/136609/stream/177634", "Emooso"},
 {"https://gfm.rastream.com/gfm-todaysmix?", "Digital Today"},
 {"https://bigrradio.cdnstream1.com/5193_128", "Christmas Home"},
 {"https://zores-radio.stream.laut.fm/zores-radio", "Zores-Class"},
 {"http://node-23.zeno.fm/7qxy24rfb9quv?rj-ttl=5&rj-tok=AAABcsr-6d4Acqgl4S_Rw7GZhQ", "LA-X"},
 {"https://streams.regenbogen.de/rr-justblack-128-aac", "Afterparty"},
 {"https://p5.p4groupaudio.com/P05_MH?", "P5 Hits"},
 {"https://hitradio-recke.stream.laut.fm/hitradio-recke", "Techrecke"},
 {"https://rsa.stream.laut.fm/rsa", "RSA"},
 {"http://naxos.cdnstream.com/1366_128", "DANCE USA"},
 {"https://stream.diazol.hu:6022/live.mp3", "Nonstop Radio"},
 {"https://radio.simulatorhits.com/radio/8000/stream", "Smashing Hits"},
 {"https://ns7.emisionlocal.com/proxy/radiounica0?mp=/stream", "Unica"},
 {"https://radiolandshut.stream.laut.fm/radiolandshut", "POPtalk"},
 {"https://live.leanstream.co/CIXXFM", "London Airwaves"},
 {"https://streamingv2.shoutcast.com/UniosunFm", "Uniosun – R&B"},
 {"https://21313.live.streamtheworld.com/WEB09_MP3_SC?", "Radio Juice"},
 {"https://streamingv2.shoutcast.com/FUNK-FRANCE", "Funk-France"},
 {"https://radio-prenzlau.stream.laut.fm/radio-prenzlau?t302=2020-06-19_11-53-11&uuid=960987ae-b9f7-497c-883f-c67f21b258ea", "Prenzlau"},
 {"http://149.56.147.197:8326/stream/;", "Hollywood – Top 40"},
 {"https://closefm.stream.laut.fm/closefm", "Close FM"},
 {"https://yobeatzfm.stream.laut.fm/yobeatzfm?t302=2020-06-19_12-35-21&uuid=04b86ef2-4fce-428e-b656-de558cf7f1c7", "Yo Trippin'"},
 {"https://party-dj-radio.stream.laut.fm/party-dj-radio", "Dirtroad"},
 {"http://67.23.249.51:9306/;", "Miami Records"},
 {"https://edge2-b.exa.live365.net/a67313", "Electrosing"},
 {"https://gooischstream.hofstreaming.nl/proxy/gooisch_main?mp=/stream", "Gooisch Music"},
 {"https://air2.radiorecord.ru:805/mdl_320", "MDL Radio"},
 {"http://bbcmedia.ic.llnwd.net/stream/bbcmedia_lrmanc_mf_q", "BBC Manchester"},
 {"https://djskl.stream.laut.fm/djskl?t302=2020-06-19_15-53-22&uuid=7f425260-f008-4d11-a0df-832b8063c8ad", "SKL Top 40"},
 {"https://sr11.inmystream.it:8026/stream", "OML-Radio"},
 {"https://online.radioruzafa.com:8005/stream", "Ruzafa"},
 {"https://node-14.zeno.fm/fkewudx4mbruv?rj-ttl=5&rj-tok=AAABcs1nu60Acf6ZTE6i-dp_eA", "Y100 Michiana"},
 {"https://koradio.stream.laut.fm/koradio", "Getting Pop/Rock"},
 {"https://17963.live.streamtheworld.com/XHMARFM_SC", "Amor – Top 100"},
 {"http://206.190.135.28:8288/stream", "Gizmo Jamz"},
 {"http://195.154.167.62:7054//;", "FLANYERS"},
 {"https://grittlefm.stream.laut.fm/grittlefm", "Grittle Seven"},
 {"https://scoopmusiquesdefilms.ice.infomaniak.ch/radioscoop-musiquesdefilms-128.mp3", "Cinemax Scoop"},
 {"https://hitradio-christmas.stream.laut.fm/hitradio-christmas?", "December Hits"},
 {"https://rtlberlin.streamabc.net/rtlb-jamfmchill-mp3-128-6575824?sABC=5rrq901n%230%231898971s4189s735p2p31064793p4838%23bayvarenqvbobk&=&amsparams=playerid:onlineradiobox;skey:1592627226", "Party Hits"},
 {"https://jivn.stream.laut.fm/jivn", "JiVN"},
 {"https://freeuk5.listen2myradio.com/live.mp3?typeportmount=s2_27550_stream_637971279", "Bizonio – Dirty Beats"},
 {"http://sanfm.ru:8000/live", "San FM"},
 {"https://n0d.radiojar.com/c1912tk5rtzuv?rj-ttl=5&rj-tok=AAABctA_HBsADnfMxxhHtQ5P5Q", "Valuable Hip-Hop"},
 {"http://stream.secousse.org:8000/secousse-street", "Secousse Street"},
 {"http://rautemusik-de-hz-fal-stream16.radiohost.de/jam", "R&B Center"},
 {"http://198.245.62.16:8150/;", "Jersey Hot"},
 {"http://new.radioserver-professional.it:8000/skillrisbackup123938", "SkillStone"},
 {"https://n02.radiojar.com/u2hpxf2kb?rj-ttl=5&rj-tok=AAABctBYqsMAUQlpNSFYKNgcoQ", "ATL's #NX100 – IBNX Radio"},
 {"http://38.96.148.28:8087/stream", "Suite 100"},
 {"https://mediagw.e-tiger.net/stream/zc12?ver=192939", "Cool FM – Light"},
 {"http://beatfmlagos.atunwadigital.streamguys1.com/beatfmlagos", "Beat FM"},
 {"https://stream.radio.co/sc111ac208/listen", "Streetz War"},
 {"https://node-16.zeno.fm/1c4vtuzvveruv?rj-ttl=5&rj-tok=AAABctBtJQMAPJ3tuhTH41VUUg", "Idiotic"},
 {"https://streamingv2.shoutcast.com/AfrobeatsNation", "Afrobeats Nation"},
 {"http://107.181.227.251/proxy/c8118?mp=/stream", "The Fam"},
 {"https://1.ice1.firststreaming.com:8000/wndv_fm.aac", "Pastime U93"},
 {"https://orbital.ice.infomaniak.ch/orbital.mp3?_=1", "ORBITAL"},
 {"https://getdeep.stream.laut.fm/getdeep?t302=2020-06-20_11-06-19&uuid=1079bf36-517e-469a-a895-caccb1accec0", "Amatory"},
 {"https://universefm.stream.laut.fm/universefm", "Universe"},
 {"https://moshheadmix.stream.laut.fm/moshheadmix", "Awakening Hits"},
 {"http://198.27.83.198:5296/stream", "Digital 440"},
 {"https://mediagw.e-tiger.net/stream/zc21?ver=324924", "Cool FM – Love"},
 {"https://homepage-radio.stream.laut.fm/homepage-radio", "Homepage"},
 {"https://everestcast.shoutcastservices.com:1285/stream", "Quick Hit 40"},
 {"http://46.20.3.246/stream/46/", "Club Pop World"},
 {"https://stream.radio.co/s4d09e922b/listen", "Dose 360"},
 {"http://s42.myradiostream.com:29160/;", "Laser 101 Curacao"},
 {"http://bigrradio-edge1.cdnstream.com/5128_128?cb=226699.mp3", "Ace R'n'B"},
 {"https://dbn313radio.radioca.st/stream", "DBN – New York"},
 {"https://mediagw.e-tiger.net/stream/zc08?ver=967903", "Cool FM – Rap"},
 {"https://veedelsradio.stream.laut.fm/veedelsradio?t302=2020-06-20_14-47-00&uuid=a944fa0b-56ba-4863-b9dc-56f6ab988778", "Veedels"},
 {"https://sonic.dattalive.com:10903/stream", "infinity"},
 {"https://rautemusik-de-hz-fal-stream12.radiohost.de/weihnachten", "Celebration"},
 {"https://streams.jdrfm.net:8443/UnR8TED_320", "Variety8TED"},
 {"http://stream.timesofoman.fm:8028/;stream.nsv", "Platinum Vibes"},
 {"http://aladnafm.shoutcaststream.com:8386/;stream.nsv", "Aladna FM"},
 {"http://servers58.com:8263/stream.mp3", "TOMATEROS"},
 {"https://saw-de-hz-fal-stream04-cluster01.radiohost.de/saw-kids_128", "Saw Kidding"},
 {"http://radio.diverzeent.com/radio/8000/radio.mp3", "Di-VerZe Jamz"},
 {"http://radiopaestum.no-ip.biz:8150/;", "Paestum"},
 {"https://node-03.zeno.fm/rbyan2zgswzuv?rj-ttl=5&rj-tok=AAABctLJwDIAh4OE7gtK8mlUHw", "Layradio Chart Show"},
 {"https://masima.rastream.com/masima-femaleradio", "Baby Live"},
 {"http://stm7.xmix.com.br:6822/;", "Radio 848 – Hip-Hop & R&B"},
 {"https://listen.radioking.com/radio/121384/stream/160960", "Paris Trendz"},
 {"https://icecast-studio21.cdnvideo.ru/S21_1", "Studio 21"},
 {"https://node-19.zeno.fm/643udufw1ceuv.mp3?rj-ttl=5&rj-tok=AAABctMn5-oAdpanJVcm4v5m4Q", "The Bahamas"},
 {"https://listen2.myradio24.com/8000", "Belorussia Hip-Hop"},
 {"http://185.150.235.162/;", "Somobor"},
 {"http://streaming.brisbaneyouthradio.com.au:8000/;", "BRISBANE YOUTH"},
 {"https://edge1-a.exa.live365.net/a11532", "Cosmo"},
 {"http://198.101.15.90:8246/;", "Australia Mix"},
 {"https://mgc.stream.laut.fm/mgc?t302=2020-06-21_08-12-54&uuid=89cfc991-3b19-4a37-8090-95e4088a8f46", "MGC 24"},
 {"https://crossmedia.stream.laut.fm/crossmedia", "Crossmedia"},
 {"https://radio-strahlemann.stream.laut.fm/radio-strahlemann?t302=2020-06-21_08-24-56&uuid=00addbe9-e880-4938-a331-663781f353a2", "Starhleman"},
 {"https://edge2-b.exa.live365.net/a31857", "JENNiRADIO"},
 {"https://charts-fm.stream.laut.fm/charts-fm", "Charts Evolution"},
 {"https://landfreak.stream.laut.fm/landfreak", "Just Love"},
 {"https://zt04.cdn.eurozet.pl/ZETPAR.mp3", "ZET Party"},
 {"https://17553.live.streamtheworld.com/WICUFMAAC.aac", "Melon"},
 {"https://bremerhavens-radio.stream.laut.fm/bremerhavens-radio", "Bremheavens"},
 {"http://cristina.torontocast.com:8170/stream", "ctuSlow"},
 {"https://proxy.live-streams.nl/havenstad", "Havestad"},
 {"http://173.193.205.96:9087/stream", "Afterparty B-Side"},
 {"https://hoodmuzic.stream.laut.fm/hoodmuzic", "don't stop Hoodz!"},
 {"https://streamingv2.shoutcast.com/RJM-RnB", "RoadBass R&B"},
 {"https://septemberwind.stream.laut.fm/septemberwind", "Septermberwind"},
 {"https://node-35.zeno.fm/snf8nycn21zuv?rj-ttl=5&rj-tok=AAABctW6940AWY32tx6-Tx6Kug", "Chesire"},
 {"https://queerbeet-opf-fm.stream.laut.fm/queerbeet-opf-fm", "Queerbeet OPF"},
 {"https://tunein.stream.laut.fm/tunein", "NonStop Party Adventure"},
 {"https://hitradio5.stream.laut.fm/hitradio5", "Broad5Active"},
 {"https://icecast.omroep.nl/funx-utrecht-sb-aac", "Ultrecht"},
 {"https://phoenix-superhits.stream.laut.fm/phoenix-superhits?t302=2020-06-21_09-29-43&uuid=3b14ad4a-8994-46e9-84e1-864b265850a8", "Alps Tour"},
 {"https://freeuk5.listen2myradio.com/live.mp3?typeportmount=s2_27550_stream_637971279", "Bizonio"},
 {"https://www.studiozef.fr/stream", "Zefolk"},
 {"https://node-14.zeno.fm/s3wdt380f9duv?rj-ttl=5&rj-tok=AAABctXZV5IAhL5N48V50WPsTQ", "Dance Hirondelle"},
 {"http://87.98.217.63:23704/stream", "Rock Live 24"},
 {"https://megapartyradio.stream.laut.fm/megapartyradio?t302=2020-06-21_09-45-59&uuid=4731fc44-9553-40ee-aac4-a0f32b9d0293", "MegaParty"},
 {"https://18693.live.streamtheworld.com/KWYLFM_SC", "Wild California"},
 {"http://powershots.skglobe.net/;", "PowerGlobe"},
 {"http://143.208.11.104:8542/stream/1/Title1", "BILLBOARD HITS"},
 {"http://198.101.15.90:8019/;stream.nsv", "Caravans"},
 {"http://s02.radio-tochka.com:4500/radio", "Audio Fresh"},
 {"http://s36.myradiostream.com:13028/;listen.mp3", "House Heads UK"},
 {"http://95.110.207.5:8000/lounge.mp3", "Freedom Lounge"},
 {"https://daniel.torontocast.com/rdmixchillout", "Ambient"},
 {"https://listen.radioking.com/radio/236671/stream/280528", "Houston Woodz Source"},
 {"http://live-zen.distinct.ro:8000/;", "Around Exclusive"},
 {"http://sc9.shoutcaststreaming.us:9106/;listen.mp3", "Columbia Illusion"},
 {"http://109.236.85.141:7000/live", "Launched Reef"}, 
 {"https://radio-stream-2.obozrevatel.com/RnB128.mp3", "Vinnytsia Hip-Hop & Pop"},
 {"https://listen.radioking.com/radio/55174/stream/92320", "Konbini Hot"},
 {"http://69.4.230.77:8080/;stream.mp3", "Burner Libary"},
 {"https://azura.shoutca.st/radio/8480/stream", "Nox 24/7"},
 {"http://stream.radioskovoroda.com:8000/radioskovoroda", "SKOVORODA Alternative"},
 {"https://energylove.ice.infomaniak.ch/energylove-high.mp3", "House Soft"},
 {"https://mued.stream.laut.fm/mued?t302=2020-06-21_10-47-16&uuid=71097862-e0ee-4863-9da4-4b77c15ec521", "Party Scene"},
 {"http://217.21.199.146:9008/;", "'Serious Blur"},
 {"https://playerservices.streamtheworld.com/api/livestream-redirect/SAM01AAC129_SC", "Strawberry"},
 {"https://stream.laut.fm/neon", "Slow Moon"},
 {"https://icecast.omroep.nl/funx-slowjamz-bb-mp3", "North Holland Jamz"},
 {"https://air2.radiorecord.ru:805/mdl_320", "Record Dance"},
 {"https://streamingv2.shoutcast.com/Radio--Compile", "Compile"},
 {"http://ice.kultradio.fm/uniradio/schalltwerk.mp3", "Schalltwerk"},
 {"http://janus.cdnstream.com:5173/stream", "Teerex"},
 {"https://echst.stream.laut.fm/echst?t302=2020-06-21_11-51-10&uuid=c3f10364-8129-49a9-a4b8-d0596076548d", "Anhalt"},
 {"http://us5.internet-radio.com:8170/stream", "We Up On It"},
 {"http://adas.nextfm.hu:8000/nextfmhu.mp3", "Powerful Pop"},
 {"https://radios.hdsynopsis.fr:1045/stream", "Fun Tracks"},
 {"http://s12.myradiostream.com:3946/;stream.nsv", "Darverse"},
 {"https://node-12.zeno.fm/7w5v3h5sfnzuv?rj-ttl=5&rj-tok=AAABctZtCfwA1h3k4tFEBha7yg", "Wave 80s"},
 {"https://groove95.live-streams.nl/live", "Groove95"},
 {"http://shoutcast.aplus.by:9000/aplus_relax_24.aac?", "Aplus Relax"},
 {"http://sender.eldoradio.de:8000/128", "Eldoradio"},
 {"http://147.162.19.241:8000/;", "Indiebue it"},
 {"https://radio8000.radioca.st/radio8000", "Eben – Top 40"},
 {"http://usa6.fastcast4u.com:5144/stream", "4Rollers"},
 {"https://ais-sa1.streamon.fm/7212_48k.aac?type=.mp3", "Aggie SN – Beats"},
 {"https://thestudio.ice.infomaniak.ch/the-studio-high.mp3", "Energy Studio"},
 {"https://energyrnbhiphop.ice.infomaniak.ch/energyrnbhiphop-high.mp3", "TrapHolderz"},
 {"http://185.126.217.8:9358/;stream.nsv", "On Air"},
 {"http://88.198.12.12:8000/live192.mp3", "Flora Cry"},
 {"http://79.120.77.11:8002/rnb", "Caprice WOW"},
 {"http://listen.radioemotion.be/;", "Emotion Belgique"},
 {"http://solid1.streamupsolutions.com:11026/stream", "Action Konitsa"},
 {"https://streamingv2.shoutcast.com/Sunrisetosunset", "Amazonas Sunrise to Sunset"},
 {"https://stream.mistofm.com.ua/spark-music", "Oxygen Spark"},
 {"http://s10.myradiostream.com:15574/;", "South Coast"},
 {"https://sv2.famcast.co.za/proxy/frd?mp=/stream", "Fashion District"},
 {"https://ohrenauf.stream.laut.fm/ohrenauf?t302=2020-06-21_13-10-10&uuid=d150ae9a-4595-4334-a727-2bd102ae8fe8", "Pop Fire"},
 {"http://stm8.streamingbage.net.br:11918/;stream.mp3", "Cidade GO"},
 {"https://player-ssl.kshost.com.br:9894/live", "Sertaneja"},
 {"http://188.165.192.5:8416/stream", "Digi-One"},
 {"https://tako.stream.laut.fm/tako?t302=2020-06-21_13-51-58&uuid=16ee57d9-5d6f-4ee7-9c7c-214bc6ce2cf4", "Taco"},
 {"https://rtlberlin.streamabc.net/rtlb-jamfmrap-mp3-128-1539918?sABC=5rrs4np2%230%231898971s4189s735p2p31064793p4838%23bayvarenqvbobk&=&amsparams=playerid:onlineradiobox;skey:1592740546", "KATANA JAMZ"},
 {"https://stream.radio.co/sc111ac208/listen", "Premiere Outlet"},
 {"https://stream.42netmedia.com:8443/karcfm-high", "Karcok"},
 {"http://heartbeatz.fm:8008/stream/1/", "More Emotions"},
 {"http://192.99.34.205:8147/stream", "Grammy Nominees"},
 {"http://stream.dotpoint.nl:8000/hotjamz", "Wherever Amsterdam"},
 {"https://str2b.openstream.co/1525", "Ontario Shots"},
 {"http://shoutcast.finestfm.fi:8000/;stream", "Finest"},
 {"http://146.71.124.10:8240/stream", "Pop Flags"},
 {"https://strmreg.1.fm/hits2000_mobile_mp3", "ActWonders"},
 {"http://wssgd.gdsinfo.com:8200/;stream.mp3", "Balaton Sound"},
 {"https://ice02.fluidstream.net/gelosa.mp3?FLID=8", "Veneto Gelosa"},
 {"http://67.23.249.51:9306/;", "Florida Hoop"},
 {"https://mscp3.live-streams.nl:8192/live", "Rythense Bachata"},
 {"https://streaming.radio.co/s7198d9355/listen", "Aviation Blue"},
 {"http://kolrega-now.cdnwz.net/now", "Northem Disctrict"},
 {"https://server2.ejeserver.com:8078/live?ext=.mp3", "Dix Bogota D.C."},
 {"http://srv2.streaming-ingenierie.fr:8160/;", "Arcueil"},
 {"https://srv4.geracaoradios.com/radio/8040/radio", "São Paulo in Love"},
 {"https://edge2-b.exa.live365.net/a79966", "Experience Amazing Lite Music"},
 {"https://streamingv2.shoutcast.com/AmericanFreeAlternativeRadio", "Heart Pop"},
 {"http://184.154.28.210:9160/;stream/1;", "Black & White OnLine"},
 {"http://sl-2396.cdnstream.com/1486_128", "Clean Soundtracks"},
 {"http://s26.myradiostream.com:4108/;", "Florida Palm – Ziggy"},
 {"http://178.32.138.88:8052/;", "Sicilia Express"},
 {"https://live.itech.host:1920/stream", "Pure Hustle"},
 {"https://radio-exclusiv.stream.laut.fm/radio-exclusiv?", "Rhine-Westphalia Pop & Rock"},
 {"https://node-13.zeno.fm/z355wcvdztzuv?rj-ttl=5&rj-tok=AAABctfRDGEAYsn2MalETmHD3A", "Felichita Club"},
 {"https://prod-34-82-180-252.wostreaming.net/newsouth-wjkkfmaac-ibc3?session-id=f18b4bf71a76b7f1318be22e4942258b", "Jackson"},
 {"http://siriusradio.hu:8500/relay_911.mp3/;", "Student Education"},
 {"https://server.radiohop.ru/radio/8000/radio.mp3", "Pop Hurry"},
 {"http://188.165.192.5:8528/;", "Bronz Part"},
 {"https://7fm.stream.laut.fm/7fm", "Freeway Seven"},
 {"https://node-26.zeno.fm/v5efxxecx5quv?rj-ttl=5&rj-tok=AAABctgNMS4Akv7hnvx1bmw_pA", "Firza"},
 {"https://supremefelix.stream.laut.fm/supremefelix?t302=2020-06-21_20-03-26&uuid=72584dea-b907-471e-8bef-719634737298", "Sup Feix"},
 {"https://servidor29.brlogic.com:8088/live?1495054204531.aac", "Butterfly"},
 {"https://derkimihd.stream.laut.fm/derkimihd?t302=2020-06-21_20-07-30&uuid=21ca3bd4-630d-4851-a044-0f7e1370a6ca", "Child"},
 {"https://0-24chartspoprock.stream.laut.fm/0-24_charts_pop_rock", "0-24 Pop Rock"},
 {"http://74.82.59.197:8264/1", "ProgRock"},
 {"https://prod-34-83-63-130.wostreaming.net/longisland-wbeafmaac-ibc1?session-id=76dee9bbec876b1b8f9964a17c2de91c", "Long Island"},
 {"http://167.114.18.120:9976/stream", "Trap United"},
 {"https://ais-sa2.cdnstream1.com/1565_128", "A100 – Sweet"},
 {"https://bluetonicbeats.stream.laut.fm/bluetonicbeats?t302=2020-06-21_20-41-04&uuid=07ebba7c-9500-4b06-a206-3004b241ad0b", "BlueTonic Beats"},
 {"http://192.227.85.169:4183/stream", "Paris – Top 40"},
 {"https://liberlandfm.s02.radio-tochka.com:4415/stream", "Rampage Pop"},
 {"https://node-08.zeno.fm/a2qx9ae7puquv?rj-ttl=5&rj-tok=AAABcthc3P0AAw6diwjIiVyRlA", "Port Saint Lucie – Party Rock"},
 {"https://node-32.zeno.fm/86uutcyn11zuv?rj-ttl=5&rj-tok=AAABcthgxhgAuKzr9rqWIkvrIA", "Taunton Dance"},
 {"http://stream.mjoy.ua:8000/radio-egoisty", "Punk-Joy"},
 {"https://listen.011fm.com:8024/stream13?cb=908203.mp3", "Detroit Hip-Hop"},
 {"http://makrodigital.net:7006/stream", "Excelencia Heart"},
 {"https://theslaughtahouze.out.airtime.pro/theslaughtahouze_a", "SlaughtaHouse"},
 {"http://184.154.45.106:8457/stream", "Radiocun"},
 {"https://streamingv2.shoutcast.com/CHOCOLAT-RADIO", "Dark Chocolate"},
 {"https://s1.radioforge.com:8063/;", "Status Quo"},
 {"https://hotradio.stream.laut.fm/hotradio", "HotFire"},
 {"http://92.61.114.195:9950/;", "Bajai"},
 {"https://mp3.radiox.ch/standard.ogg", "Rock-X"},
 {"https://spinnin-charts.stream.laut.fm/spinnin-charts", "TOP Charts – Hesse"},
 {"https://node-35.zeno.fm/8m2f7nbvyrquv?rj-ttl=5&rj-tok=AAABctjAJd0AIu0fmbL2HS5gYw", "Aragon POP"},
 {"http://198.245.62.16:8042/;", "Albuquerque"},
 {"https://edge1-a.exa.live365.net/a14836", "Ohio Greatest"},
 {"https://play10.tikast.com/proxy/ladyl?mp=/stream", "Lady"},
 {"http://188.134.10.11:8000/;stream.nsv", "DanceTronic"},
 {"https://18053.live.streamtheworld.com/WAOAFM_SC", "Space Coast"},
 {"https://node-29.zeno.fm/ha3652g3ueruv?rj-ttl=5&rj-tok=AAABctqbA3cA0gddmluILYaxJw", "Buenos Aires – Sao Party"},
 {"http://195.154.167.62:7054//;", "Loreto FX"},
 {"https://streamingv2.shoutcast.com/TheSoundLabUK", "Bristol Beatlab"},
 {"https://mbmusik.stream.laut.fm/mbmusik?t302=2020-06-22_07-59-33&uuid=4b2fc8de-0777-48f5-90ed-4d76328857c3", "MB – Dance"},
 {"http://151.80.42.191:8016/stream", "Jacksonville Total"},
 {"http://129.170.152.51:8000/listen", "Dartmouth College"},
 {"http://69.4.230.77:8080/;stream.mp3", "Grunge Burner"},
 {"https://listen6.myradio24.com/4432", "AntiBunny"},
 {"https://streams.regenbogen.de/rr-justblack-128-aac", "Mannheim"},
 {"http://204.80.232.29:9996/listen", "Pennsylvania Contemporary"},
 {"http://thassos.cdnstream.com:5485/stream?1487949259188.mp3", "Shaking Rocket"},
 {"https://node-11.zeno.fm/czvfg83vd6quv?rj-ttl=5&rj-tok=AAABctwG6x0A7_D8K1p5CC0phA", "Fly Away"},
 {"https://bestof2013.stream.laut.fm/bestof2013", "Hamburg Hits"},
 {"https://mshit-radio.stream.laut.fm/mshit-radio", "Standing"},
 {"https://node-18.zeno.fm/9a87d8v1v8quv?rj-ttl=5&rj-tok=AAABctwcRMMABDQ67P7wf6M2Iw", "Live it up"},
 {"http://149.56.185.82:8097/;", "Liberated Mould"},
 {"https://streamingv2.shoutcast.com/FUNK-FRANCE", "Funk France"},
 {"http://s02.radio-tochka.com:4500/radio", "Disappear Walkin'"},
 {"https://expendiafm.stream.laut.fm/expendiafm", "Expendia Pop"},
 {"http://176.9.92.205/oxigenio_mp3", "Lissabon Oxygeno"},
 {"https://streams.iloveradio.de/iloveradio8.mp3?hadpreroll", "Christmas everywhere"},
 {"http://melinda.radiobellissima.it:8020/stream", "Santa Greet"},
 {"http://bitsmitter.com:9008/;?1495260479898.mp3", "Mistletoe"},
 {"https://streaming.radiostreamlive.com/radiosantaclaus_devices", "He comes on a sled with reindeer"},
 {"http://stream01.my105.ch/my105xmas.mp3", "Snowpillow"},
 {"https://radio-stream-1.obozrevatel.com/novogodnie_pesni128.mp3", "The White Light"},
 {"http://naxos.cdnstream.com/1304_64", "Winter Park"},
 {"http://air.radiorecord.ru:8102/sd90_320", "90s Vibes"},
}

addEventHandler("onClientPlayerVehicleEnter", getLocalPlayer(),

	function(theVehicle)
		setRadioChannel(0)

		radio = getElementData(theVehicle, "vehicle:radio") or 0

		setElementData(theVehicle, "vehicle:radio", radio)
		if radio > 0  then
			designation = radio
			setElementData(theVehicle, "vehicle:radio:status", 1)
			Image = 1
			triggerServerEvent("car:radio:sync", getLocalPlayer(), designation)
		else
			Image = "kikapcsolva"
			setElementData(theVehicle, "vehicle:radio:status", 0)
		end

		bindKey("r","down", createVehicleRadio)

	end

)

addEventHandler("onClientPlayerVehicleExit", getLocalPlayer(),

	function(theVehicle)
		show = false

		unbindKey("r","down", createVehicleRadio)

	end

)

addEventHandler("onClientResourceStart", getResourceRootElement(getThisResource()) , function ()
	if isPedInVehicle(localPlayer) then
		local vehicle = getPedOccupiedVehicle(localPlayer)

		setRadioChannel(0)

		radio = getElementData(vehicle, "vehicle:radio") or 0
		setElementData(vehicle, "vehicle:radio:status", 0)
		Image = "kikapcsolva"

		setElementData(vehicle, "vehicle:radio", radio)

		bindKey("r","down", createVehicleRadio)
	end
end)
function createVehicleRadio ()
	--if  getPedOccupiedVehicleSeat(localPlayer) == 1  then
		local vehicle = getPedOccupiedVehicle(localPlayer)
		local radio = getElementData(vehicle, "vehicle:radio") or 0
		if not show  then
			show = true
			removeEventHandler("onClientRender", root, createRadioPanel)
			addEventHandler("onClientRender", root, createRadioPanel)
		elseif show then
			show = false
			removeEventHandler("onClientRender", root, createRadioPanel)
		end
	--end
end

function createRadioPanel()
	if not show then return end
	local vehicle = getPedOccupiedVehicle(localPlayer)
	if isPedInVehicle(localPlayer) then
		local radio = getElementData(vehicle, "vehicle:radio") or 0
		local radioStatus = getElementData(vehicle, "vehicle:radio:status") or 0
		if radioStatus == 0 or radio == 0 then
			dxDrawImage(sx/2-256, sy/2-256, 512, 512, "files/background.png")
			dxDrawImage(sx/2-230,sy/2-240,31,31,"files/ledoff.png")
			dxDrawImage(sx/2-230,sy/2-200,45,28,"files/pout.png")

		else
			local newStation =  getElementData(vehicle, "vehicle:radio") or 0
			if newStation <= 1 then
				designation = 1
				setElementData(vehicle, "vehicle:radio", designation)
			end
			if newStation >= #musicTable then
				designation = 1
				setElementData(vehicle, "vehicle:radio", designation)
			end
			dxDrawImage(sx/2-256, sy/2-256, 512, 512, "files/background.png")
			dxDrawImage(sx/2-230,sy/2-240,31,31,"files/ledon.png")
			dxDrawImage(sx/2-230,sy/2-200,45,28,"files/pin.png")

			if isCursorOnBox(sx/2-55,sy/2-30,37,37) then
				dxDrawImage(sx/2-55,sy/2-30,37,37,"files/l2.png")
			else
				dxDrawImage(sx/2-55,sy/2-30,37,37,"files/l1.png")
			end
			if isCursorOnBox(sx/2+47,sy/2-30,37,37) then
				dxDrawImage(sx/2+47,sy/2-30,37,37,"files/r2.png")
			else
				dxDrawImage(sx/2+47,sy/2-30,37,37,"files/r1.png")
			end
			local hangero = getElementData(vehicle, "vehicle:radio:volume") or 40
			if hangero < 0 then
				hangero = 0
			end
			if hangero > 100 then
				hangero = 100
			end
			dxDrawText(musicTable[newStation][2], sx/2-160,sy/2-190,sx/2,sy/2, tocolor(255, 255, 255, 255), 2, "default", "left", "top", false, false, false, true )

			dxDrawImage(sx/2+100,sy/2+25,107,3,"files/sliderBG.png")
			dxDrawImage(sx/2+100+hangero,sy/2+25-2,23,6,"files/sliderBG.png",0,0,0,tocolor(189, 91, 153,255))
			dxDrawImage(sx/2+170,sy/2,12,11,"files/volume.png")
			dxDrawText(hangero.. "%", sx/2+220,sy/2-2,sx/2+220,sy/2-2, tocolor(189, 91, 153, 255), 1.0, "default", "right", "top", false, false, false, true )
			clientRenderFunc()
		end
	end
end

function clientRenderFunc()
	if isElement(newSoundElement) then
    local bt = getSoundFFTData(newSoundElement,2048,257)
    if(not bt) then return end
        for i=1,250 do
            bt[i] = math.sqrt(bt[i])*250 --scale it (sqrt to make low values more visible)
            dxDrawRectangle(sx/2+i-108,sy/2-90-bt[i]/2,1,bt[i], tocolor(255, 44, 85,255))
        end
    end
end

function menuClick(gomb,stat,x,y)
	if not show then return end
	if isPedInVehicle(localPlayer) then
		if gomb == "left" and stat == "down" then
			--if  getPedOccupiedVehicleSeat(localPlayer) == 1  then
				local vehicle = getPedOccupiedVehicle(localPlayer)
				if (dobozbaVan(sx/2-55,sy/2-30,37,37, x, y)) then
					if designation >= 1 and (getElementData(vehicle, "vehicle:radio:status") or 0) == 1 then
						designation = designation - 1
						setElementData(vehicle, "vehicle:radio", designation )
						local selectSound = playSound ( "files/stationswitch.mp3", false )
						setSoundVolume(selectSound, 0.2)
					end
				elseif (dobozbaVan(sx/2+47,sy/2-30,37,37, x, y)) then
					if designation >= 1 and designation <= #musicTable  and (getElementData(vehicle, "vehicle:radio:status") or 0) == 1 then
						designation = designation + 1
						local selectSound = playSound ( "files/stationswitch.mp3", false )
						setSoundVolume(selectSound, 0.2)
						setElementData(vehicle, "vehicle:radio", designation )
					end
				elseif (dobozbaVan(sx/2-230,sy/2-200,45,28, x, y)) then
					if (getElementData(vehicle, "vehicle:radio:status") or 0) == 0 then
						setElementData(vehicle, "vehicle:radio:status", 1)
						designation = 1
						setElementData(vehicle, "vehicle:radio", designation)
						local powerSound = playSound ( "files/poweronoff.mp3", false )
						setSoundVolume(powerSound, 0.2)
					else
						setElementData(vehicle, "vehicle:radio:status", 0)
						setElementData(vehicle, "vehicle:radio", 0)
						designation = 0
						local powerSound = playSound ( "files/poweronoff.mp3", false )
						setSoundVolume(powerSound, 0.2)
					end
				end
				triggerServerEvent("car:radio:sync", getLocalPlayer(), designation)
			--end
		end
	end
end
addEventHandler("onClientClick",getRootElement(),menuClick)

--<[ Görgetés ]>--
bindKey("mouse_wheel_down", "down",
	function()
		if show and isPedInVehicle(localPlayer) then
			local theVehicle = getPedOccupiedVehicle(getLocalPlayer())
			local hangero = getElementData(theVehicle, "vehicle:radio:volume") or 25
			if hangero > 0 and hangero <= 105 then
				hangero = hangero - 10
				setElementData(theVehicle, "vehicle:radio:volume", hangero)
				triggerServerEvent("car:radio:vol", getLocalPlayer(), tonumber(hangero))
			end
		end
	end
)


bindKey("mouse_wheel_up", "down",
	function()
		if show and isPedInVehicle(localPlayer) then
			local theVehicle = getPedOccupiedVehicle(getLocalPlayer())
			local hangero = getElementData(theVehicle, "vehicle:radio:volume") or 25
			if hangero < 100 then
				hangero = hangero + 10
				setElementData(theVehicle, "vehicle:radio:volume", hangero)
				triggerServerEvent("car:radio:vol", getLocalPlayer(), tonumber(hangero))
			end
		end
	end
)
--<[ Görgetés vége ]>--

function dobozbaVan(dX, dY, dSZ, dM, eX, eY)
	if(eX >= dX and eX <= dX+dSZ and eY >= dY and eY <= dY+dM) then
		return true
	else
		return false
	end
end

function isCursorOnBox(xS,yS,wS,hS)
	if(isCursorShowing()) then
		XY = {guiGetScreenSize()}
		local cursorX, cursorY = getCursorPosition()
		cursorX, cursorY = cursorX*XY[1], cursorY*XY[2]
		if(cursorX >= xS and cursorX <= xS+wS and cursorY >= yS and cursorY <= yS+hS) then
			return true
		else
			return false
		end
	end
end

addEventHandler("onClientElementDestroy", getRootElement(), function ()
	local radio = getElementData(source, "vehicle:radio") or 0

	if getElementType(source) == "vehicle" and radio ~= 0 then
		if isElement(newSoundElement) then
			stopSound(newSoundElement)
		end
		setElementData(source, "vehicle:radio", 0)
	end
end)

addEventHandler ( "onClientElementDataChange", getRootElement(),

	function ( dataName )
		if getElementType ( source ) == "vehicle" and dataName == "vehicle:radio" then
				local newStation =  getElementData(source, "vehicle:radio") or 0

				if (isElementStreamedIn (source)) then
					if newStation ~= 0 then
						if (soundElementsOutside[source]) then
							stopSound(soundElementsOutside[source])
						end

						local x, y, z = getElementPosition(source)

						local song = nil

						song = musicTable[newStation][1]
						newSoundElement = playSound3D(song, x, y, z, true)
						soundElementsOutside[source] = newSoundElement
						updateLoudness(source)
						setElementDimension(newSoundElement, getElementDimension(source))
						setElementDimension(newSoundElement, getElementDimension(source))
					else
						if (soundElementsOutside[source]) then
							stopSound(soundElementsOutside[source])
							soundElementsOutside[source] = nil
						end
					end
				end
		elseif getElementType(source) == "vehicle" and dataName == "vehicle:windowstat" then
			if (isElementStreamedIn (source)) then
				if (soundElementsOutside[source]) then
					updateLoudness(source)
				end
			end
		elseif getElementType(source) == "vehicle" and dataName == "vehicle:radio:volume" then
			if (isElementStreamedIn (source)) then
				if (soundElementsOutside[source]) then
					updateLoudness(source)
				end
			end
		end
	end
)

addEventHandler("onClientPlayerRadioSwitch", getLocalPlayer(), function()

	cancelEvent()

end)

function updateLoudness(theVehicle)
	if (soundElementsOutside[theVehicle]) then

		local windowState = getElementData(theVehicle, "vehicle:windowstat") or 1

		local carVolume = getElementData(theVehicle, "vehicle:radio:volume") or 25

		carVolume = carVolume / 100
		--  ped is inside
		if (getPedOccupiedVehicle( getLocalPlayer() ) == theVehicle) then
			setSoundMinDistance(soundElementsOutside[theVehicle], 8)
			setSoundMaxDistance(soundElementsOutside[theVehicle], 70)
			setSoundVolume(soundElementsOutside[theVehicle], 0.6775*carVolume)
		elseif (getVehicleType(theVehicle) == "Boat") then
			setSoundMinDistance(soundElementsOutside[theVehicle], 25)
			setSoundMaxDistance(soundElementsOutside[theVehicle], 50)
			setSoundVolume(soundElementsOutside[theVehicle], 0.6725*carVolume)
		elseif (windowState == 1) then --letekerve az ablak
			setSoundMinDistance(soundElementsOutside[theVehicle], 5)
			setSoundMaxDistance(soundElementsOutside[theVehicle], 15.5)
			setSoundVolume(soundElementsOutside[theVehicle], 0.6725*carVolume)
		elseif (windowState == 0 ) then --feltekerve az ablak
			setSoundMinDistance(soundElementsOutside[theVehicle], 3)
			setSoundMaxDistance(soundElementsOutside[theVehicle], 7.5)
			setSoundVolume(soundElementsOutside[theVehicle], 0.6725*carVolume)
		else
			setSoundMinDistance(soundElementsOutside[theVehicle], 3)
			setSoundMaxDistance(soundElementsOutside[theVehicle], 10)
			setSoundVolume(soundElementsOutside[theVehicle], 0.6725*carVolume)
		end
	end
end

addEventHandler( "onClientPreRender", getRootElement(),
	function()
		if soundElementsOutside ~= nil then
			for element, sound in pairs(soundElementsOutside) do
				if (isElement(sound) and isElement(element)) then
					local x, y, z = getElementPosition(element)
					setElementPosition(sound, x, y, z)
					setElementInterior(sound, getElementInterior(element))
					getElementDimension(sound, getElementDimension(element))
				end
			end
		end
	end
)

function spawnSound(theVehicle)
		local newSoundElement = nil
    if getElementType( theVehicle ) == "vehicle" then

			local radioStation = getElementData(theVehicle, "vehicle:radio") or 0
			if radioStation ~= 0 then
				if (soundElementsOutside[theVehicle]) then
					stopSound(soundElementsOutside[theVehicle])
				end

				local x, y, z = getElementPosition(theVehicle)

				song = musicTable[radioStation][1]
				newSoundElement = playSound3D(song, x, y, z, true)
				soundElementsOutside[theVehicle] = newSoundElement
				setElementDimension(newSoundElement, getElementDimension(theVehicle))
				setElementDimension(newSoundElement, getElementDimension(theVehicle))
				updateLoudness(theVehicle)
			end
    end
end


function removeTheEvent()
	removeEventHandler("onClientPreRender", getRootElement(), showStation)
	textShowing = false
end



function saveRadio(station)

	cancelEvent()
	local radios = 0
	if (station == 0) then
		return
	end
	local vehicle = getPedOccupiedVehicle(getLocalPlayer())

	if (vehicle) then

		if getVehicleOccupant(vehicle) == getLocalPlayer() or getVehicleOccupant(vehicle, 1) == getLocalPlayer() then
			if (station == 12) then
				if (radio == 0) then
					radio = totalStreams + 1
				end

				if (streams[radio - 1]) then
					radio = radio - 1
				else
					radio = 0
				end
			elseif (station == 0) then
				if (streams[radio+1]) then
					radio = radio+1
				else
					radio = 0
				end
			end
			if not textShowing then
				addEventHandler("onClientPreRender", getRootElement(), showStation)
				if (isTimer(theTimer)) then
					resetTimer(theTimer)
				else
					theTimer = setTimer(removeTheEvent, 6000, 1)
				end
				textShowing = true
			else
				removeEventHandler("onClientPreRender", getRootElement(), showStation)
				addEventHandler("onClientPreRender", getRootElement(), showStation)
				if (isTimer(theTimer)) then
					resetTimer(theTimer)
				else
					theTimer = setTimer(removeTheEvent, 6000, 1)
				end
			end
			triggerServerEvent("car:radio:sync", getLocalPlayer(), radio)
		end
	end
end



addEventHandler( "onClientElementStreamIn", getRootElement( ),
    function ( )
			spawnSound(source)
    end
)


addEventHandler( "onClientElementStreamOut", getRootElement( ),
    function ( )
		local newSoundElement = nil
      if getElementType( source ) == "vehicle" then
				if (soundElementsOutside[source]) then
					stopSound(soundElementsOutside[source])
					soundElementsOutside[source] = nil
				end
      end
    end
)
