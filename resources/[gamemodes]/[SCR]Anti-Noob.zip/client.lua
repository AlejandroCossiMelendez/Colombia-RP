function tomouDano ( attacker )
   if not getElementData ( source, "emCombate" ) then
    if not (attacker) then return end
     if getElementType(attacker) == "player" then
      setElementData ( source, "emCombate", true )
	  setTimer ( setElementData, 10000, 1, source, "emCombate", false )
    end
  end
end
addEventHandler ( "onClientPlayerDamage", getLocalPlayer(), tomouDano )