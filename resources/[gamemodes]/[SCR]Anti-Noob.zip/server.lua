function pegaVida ( thePlayer )
  local dano = getElementData ( thePlayer, "emCombate" )
    if dano then
	  local pickupType = getPickupType ( source )
		if (pickupType == 0) or (pickupType == 1) then
			cancelEvent( )
		end
	end
end 
addEventHandler ( "onPickupUse", getRootElement(), pegaVida )

function morreu ( )
	if getElementData ( source, "emCombate" ) then
		setElementData ( source, "emCombate", false )
	end
end
addEventHandler ( "onPlayerWasted", getRootElement(), morreu )