local subTrackOnSoundDown = 0.1
local subTrackOnSoundUp = 0.1
local spam
local spam2

function print(message, r, g, b)
    outputChatBox(message, r, g, b)
end

local rx, ry = guiGetScreenSize()
button = {}
window = guiCreateWindow((rx - 295), (ry / 2 - 253 / 2), 293, 253, "Speakers", false)
guiWindowSetSizable(window, false)
guiSetVisible(window, false)
CurrentSpeaker = guiCreateLabel(8, 33, 254, 17, "Tienes un parlante: No", false, window)
volume = guiCreateLabel(10, 50, 252, 17, "Volumen Actual: 100%", false, window)
pos = guiCreateLabel(10, 66, 252, 15, "X: 0 | Y: 0 | Z: 0", false, window)
guiCreateLabel(11, 81, 251, 15, "URL:", false, window)
url = guiCreateEdit(11, 96, 272, 23, "http://977music.com/itunes/mix.pls", false, window)
button["place"] = guiCreateButton(9, 129, 274, 20, "Sacar Parlante", false, window)
button["remove"] = guiCreateButton(9, 159, 274, 20, "Guardar Parlante", false, window)
button["v-"] = guiCreateButton(9, 189, 128, 20, "Volumen -", false, window)
button["v+"] = guiCreateButton(155, 189, 128, 20, "Volumen +", false, window)
button["close"] = guiCreateButton(9, 219, 274, 20, "Salir", false, window)

local isSound = false
addEvent("onPlayerViewSpeakerManagement", true)
addEventHandler("onPlayerViewSpeakerManagement", root,
    function(current)
        local toState = not guiGetVisible(window)
        guiSetVisible(window, toState)
        showCursor(toState)
        if (toState == true) then
            guiSetInputMode("no_binds_when_editing")
            local x, y, z = getElementPosition(localPlayer)
            guiSetText(pos, "X: " .. math.floor(x) .. " | Y: " .. math.floor(y) .. " | Z: " .. math.floor(z))
            if (current) then
                guiSetText(CurrentSpeaker, "Tienes un parlante: Si")
                isSound = true
            else
                guiSetText(CurrentSpeaker, "Tienes un parlante: No")
            end
        end
    end
)

addEventHandler("onClientGUIClick", root,
    function()
        if (source == button["close"]) then
            guiSetVisible(window, false)
            showCursor(false)
        elseif (source == button["place"]) then
            if (isURL()) then
				if spam and isTimer(spam) then return print("Dont trates de bugear el sistema, espero 5 segundos.", 255, 0, 0) end
				spam = setTimer(function() end,5000,1)
                triggerServerEvent("onPlayerPlaceSpeakerBox", localPlayer, guiGetText(url), isPedInVehicle(localPlayer))
                guiSetText(CurrentSpeaker, "Tienes un parlante: Si")
                isSound = true
                guiSetText(volume, "Volumen: 100%")
            else
                print("Primero debes poner la URL.", 255, 0, 0)
            end
        elseif (source == button["remove"]) then
			if spam2 and isTimer(spam2) then return print("No hagas spam, espera 3 segundos.", 255, 0, 0) end
			spam2 = setTimer(function() end,3000,1)
            triggerServerEvent("onPlayerDestroySpeakerBox", localPlayer)
            guiSetText(CurrentSpeaker, "Tienes un parlante: No")
            isSound = false
            guiSetText(volume, "Volumen: 100%")
        elseif (source == button["v-"]) then
            if (isSound) then
                local toVol = math.round(getSoundVolume(speakerSound[localPlayer]) - subTrackOnSoundDown, 2)
                if (toVol > 0.0) then
                    print("Volume set to " .. math.floor(toVol * 100) .. "%!", 0, 255, 0)
                    triggerServerEvent("onPlayerChangeSpeakerBoxVolume", localPlayer, toVol)
                    guiSetText(volume, "Current Volume: " .. math.floor(toVol * 100) .. "%")
                else
                    print("El volumen no puede bajar más.", 255, 0, 0)
                end
            end
        elseif (source == button["v+"]) then
            if (isSound) then
                local toVol = math.round(getSoundVolume(speakerSound[localPlayer]) + subTrackOnSoundUp, 2)
                if (toVol < 1.1) then
                    print("Volume set to " .. math.floor(toVol * 100) .. "%!", 0, 255, 0)
                    triggerServerEvent("onPlayerChangeSpeakerBoxVolume", localPlayer, toVol)
                    guiSetText(volume, "Current Volume: " .. math.floor(toVol * 100) .. "%")
                else
                    print("El volumen no puede subir más.", 255, 0, 0)
                end
            end
        end
    end
)

speakerSound = {}
addEvent("onPlayerStartSpeakerBoxSound", true)
addEventHandler("onPlayerStartSpeakerBoxSound", root,
    function(who, url, isCar)
        if (isElement(speakerSound[who])) then
            destroyElement(speakerSound[who])
        end
        if string.len(url) > 150 then
            return
        end
        local x, y, z = getElementPosition(who)
        speakerSound[who] = playSound3D(url, x, y, z, true)
        setSoundVolume(speakerSound[who], 1)
        setSoundMinDistance(speakerSound[who], 35)
        setSoundMaxDistance(speakerSound[who], 40)
        if (isCar) then
            local car = getPedOccupiedVehicle(who)
            attachElements(speakerSound[who], car, 0, 5, 1)
        end
    end
)

addEvent("onPlayerDestroySpeakerBox", true)
addEventHandler("onPlayerDestroySpeakerBox", root,
    function(who)
        if (isElement(speakerSound[who])) then
            destroyElement(speakerSound[who])
        end
    end
)

addEvent("onPlayerChangeSpeakerBoxVolumeC", true)
addEventHandler("onPlayerChangeSpeakerBoxVolumeC", root,
    function(who, vol)
        if (isElement(speakerSound[who])) then
            setSoundVolume(speakerSound[who], tonumber(vol))
        end
    end
)

function isURL()
    if string.len(tostring(url)) < 150 then
        if (guiGetText(url) ~= "") then
            return true
        else
            return false
        end
    end
end

function math.round(number, decimals, method)
    decimals = decimals or 0
    local factor = 10 ^ decimals
    if (method == "ceil" or method == "floor") then
        return math[method](number * factor) / factor
    else
        return tonumber(("%." .. decimals .. "f"):format(number))
    end
end
