function crearbici(player)
    local x, y, z = getElementPosition(player)
    local xr, yr, zr = getElementRotation(player)
    local dinero = getPlayerMoney(player)
    outputChatBox("Su dinero es de $" .. dinero, 0, 255, 0)
    if (dinero >= 500) then
    takePlayerMoney(player, 500)
    auto = createVehicle ( 509, x, y+2, z)
    setElementRotation(auto, xr, yr, zr)
    warpPedIntoVehicle( player, auto)
    outputChatBox("Ha arrendado su bicicleta con exito!. Valor= $500", player, 0, 255, 0)
else 
    outputChatBox("((No tienes el dinero suficiente.))", player, 255, 0, 0)
end
end

addCommandHandler ("arrendarbici", crearbici )