function loadSettingsRecursively(node, cache)
	local cache = cache or {};
	
	for i, child in ipairs (xmlNodeGetChildren (node)) do 
		local nodeName = xmlNodeGetName (child);
		local prefix = xmlNodeGetAttribute (child, "prefix");
		if nodeName ~= "group" then 			
			local value = xmlNodeGetAttribute (child, "value");
			if prefix then 
				cache[prefix] = value;
			else
				cache[i] = value;
			end	
		else
			cache[prefix] = {};
			loadSettingsRecursively(child, cache[prefix]);
		end
	end
	return cache;
end

local config = xmlLoadFile("config/settings.xml");
settings = loadSettingsRecursively(config);
xmlUnloadFile(config);

function moveDrone(key, por)
	if keys[key] then
		triggerServerEvent ("drone.ctrl", localPlayer, entity.ped, keys[key], por);
	end	
end

function stopDrone()
	triggerServerEvent ("drone.stop", localPlayer);
end

function toggleDroneCamera()
	camera = not camera;
end	

function startDrone(drone, ped)
	entity.drone = drone;
	entity.ped = ped;
	addEventHandler ("onClientPreRender", root, checkDrone);
	addEventHandler ("onClientKey", root, moveDrone);
	bindKey (settings.main.cm_bind, "down", toggleDroneCamera);
end

addEvent ("drone.ctrl_c", true);
addEventHandler ("drone.ctrl_c", root, 
	function (ped, ctrl, state)
		if not isElement (ped) then return; end
		setPedControlState (ped, ctrl, state);
	end
);	

addEvent ("drone.start", true);
addEventHandler ("drone.start", root,
	function (drone, ped)
		startDrone(drone, ped);
		setPlayerHudComponentVisible ("radar", false)
	end
);	

function terminateDroneOptions()
	removeEventHandler ("onClientKey", root, moveDrone);
	removeEventHandler ("onClientPreRender", root, checkDrone);
	mfx = nil;
	setCameraTarget (localPlayer);
	setPlayerHudComponentVisible ("radar", true)
	toggleAllControls(true);
	unbindKey (settings.main.cm_bind, "down", toggleDroneCamera);
	for i, v in ipairs (getElementsByType"player") do 
		setPlayerNametagShowing(v, true);
	end	
end	
addEventHandler ("onClientResourceStop", resourceRoot, terminateDroneOptions);
addEvent ("drone.stop", true)
addEventHandler ("drone.stop", root, terminateDroneOptions);

addEventHandler ("onClientResourceStart", resourceRoot, 
	function ()
		local txd = engineLoadTXD ("files/drone.txd");
		engineImportTXD(txd, 501);
		local dff = engineLoadDFF ("files/drone.dff");
		engineReplaceModel(dff, 501);
	end
);	