shamal_interiors = {}
local shamal_interior_collision = createColSphere(1.74491, 28.27952, 1199.59375, 50)

function getUnusedDimension()
	local unused = 0
	local ok = false
	while not ok do
		ok = true
		unused = unused + 1
		for i, v in pairs(shamal_interiors) do
			if v["dimension"] == unused then
				ok = false
				break
			end
		end
	end
	return unused
end

function getShamalInteriorByElement(element)
	local found = false
	for i, v in pairs(shamal_interiors) do
		if v["element"] == element then
			found = i
			break
		end
	end
	return found
end

addEvent("onPlayerShamalEnterRequest", true)
addEvent("onPlayerShamalExitRequest", true)

function isPlayer(element)
	if not isElement(element) then	
		return false
	end
	if getElementType(element) ~= "player" then
		return false
	end
	return true
end

function isElementInShamal(element)
	if not isElement(element) then
		return false
	end
	local int = getElementInterior(element)		
	if int ~= 1 then
		return false
	end
	local dim = getElementDimension(element)
	if dim == 0 then
		return false
	end
	if not (isElementWithinColShape(element, shamal_interior_collision)) then
		return false
	end
	return true
end

function isPlayerInShamal(player)
	if not isPlayer(player) then
		return false
	end
	if isPedInVehicle(player) then
		return false
	end
	if not isElementInShamal(player) then
		return false
	end
	return true
end

addEvent("onPlayerFireInShamal", true)
addEventHandler("onPlayerFireInShamal", getRootElement(),
	function()
		if wasEventCancelled() then
			return
		end
		if not isPlayerInShamal(source) then
			cancelEvent(true)
			return
		end
		local dim = getElementDimension(source)
		local shamal = getShamalByDimension(dim)
		if not shamal then
			cancelEvent(true)
			return
		end
		local health = getElementHealth(shamal)
		if health >= 10 then
			setElementHealth(shamal, 0)
		end
	end
)

function enterExitShamal(player, shamal, posX, posY, posZ, dimension, rotation, int)
	setTimer(
		function()
			if not isElement(player) then
				return
			end
			setElementInterior(player, int)
			setElementDimension(player, dimension)
			setElementPosition(player, posX, posY, posZ)
			setElementRotation(player, 0, 0, rotation)
		end
	, 500, 1)
	setVehicleDoorOpenRatio(shamal, 2, 1, 500)
	setTimer(
		function()
			if not isElement(shamal) then
				return
			end
			setVehicleDoorOpenRatio(shamal, 2, 0, 500)
		end
	, 1000, 1)
end

function getShamalByDimension(dimension)
	if dimension == 0 then
		return false
	end
	local found_shamal = false
	for i, v in pairs(shamal_interiors) do
		if v["dimension"] == dimension then
			found_shamal = i
			break
		end
	end
	if not shamal_interiors[found_shamal] then
		return false
	end
	if not isElement(shamal_interiors[found_shamal]["element"]) then
		return false
	end
	found_shamal = shamal_interiors[found_shamal]["element"]
	return found_shamal
end

addEventHandler("onPlayerShamalExitRequest", getRootElement(),
	function()
		if wasEventCancelled() then
			return
		end
		local ply = source
		if not isPlayerInShamal(ply) then
			cancelEvent(true)
			return
		end
		local dim = getElementDimension(source)
		local found_shamal = getShamalByDimension(dim)
		if not isElement(found_shamal) then
			cancelEvent(true)
			return
		end
		if isElementInWater(found_shamal) then
			cancelEvent(true)
			return
		end
		local rx, ry, rz = getElementRotation(found_shamal)
		local x, y, z = getElementPosition(found_shamal)
		local int = getElementInterior(found_shamal)
		local dim = getElementDimension(found_shamal)
		x = x + 3.25 * math.cos(math.rad(rz + 90))
		y = y + 3.25 * math.sin(math.rad(rz + 90))
		rz = rz + 90
		x = x + 2.5 * math.cos(math.rad(rz + 90))
		y = y + 2.5 * math.sin(math.rad(rz + 90))
		z = z - 0.5
		local ply = source
		enterExitShamal(ply, found_shamal, x, y, z, dim, rz, 0)
	end
)

function isVehicle(element)
	if not isElement(element) then
		return false
	end
	if getElementType(element) ~= "vehicle" then
		return false
	end
	return true
end

function isVehicleShamal(element)
	if not isElement(element) then
		return false
	end
	local model = getElementModel(element)
	if model ~= 519 then
		return false
	end
	return true
end

function isVehicleBlownOrExploding(element)
	if not isElement(element) then
		return false
	end
	if not isVehicle(element) then
		return false
	end
	if not isVehicleBlown(element) and getElementHealth(element) > 200 then
		return false
	end
	return true
end

addEventHandler("onPlayerShamalEnterRequest", getRootElement(),
	function(vehicle)
		if wasEventCancelled() then
			return
		end
		if not isVehicle(vehicle) then
			cancelEvent(true)
			return
		end
		if not isPlayer(source) then
			cancelEvent(true)
			return
		end
		if isPedInVehicle(source) then
			cancelEvent(true)
			return
		end
		if not isVehicleShamal(vehicle) then
			cancelEvent(true)
			return
		end
		if isVehicleBlownOrExploding(vehicle) then
			cancelEvent(true)
			return
		end
		if isElementInWater(vehicle) then
			cancelEvent(true)
			return
		end
		local x, y, z = getElementPosition(source)
		local vx, vy, vz = getElementPosition(vehicle)
		if getDistanceBetweenPoints3D(x, y, z, vx, vy, vz) > 5 then
			cancelEvent(true)
			return
		end
		local int = getShamalInteriorByElement(vehicle)
		if not int then
			cancelEvent(true)
			return
		end
		dim = shamal_interiors[int]["dimension"]
		

		local ply = source
		enterExitShamal(ply, vehicle, 3.61996, 23.13369, 1199.60120, dim, 90, 1)
		
	end
)

function killPlayersInShamalInterior(dimension, dontexplode)
	local players = getElementsWithinColShape(shamal_interior_collision)
	for i2, v2 in pairs(players) do
		if getElementDimension(v2) == dimension then
			killPed(v2)
			if not dontexplode then
				triggerClientEvent(v2, "onShamalExplosionRequest", v2)
			end
		end
	end
end

function removeElementShamalInterior(element)
	local index = getShamalInteriorByElement(element)
	if index then
		killPlayersInShamalInterior(shamal_interiors[index]["dimension"])
		table.remove(shamal_interiors, index)
	end
end

function createShamalInteriorForElement(element)
	local dim = getUnusedDimension()
	shamal_interiors[#shamal_interiors + 1] = {
		["element"] = element,
		["dimension"] = dim
	}
end



setTimer(
	function()
		local vehicles = getElementsByType("vehicle")
		local vehiclesToDestroy = {}
		for i, v in pairs(vehicles) do
			if isElement(v) then
				if isElementInShamal(v) then
					removeElementShamalInterior(v)
					vehiclesToDestroy[#vehiclesToDestroy + 1] = v
				else
					if isVehicleShamal(v) then
						if isVehicleBlownOrExploding(v) then
							removeElementShamalInterior(v)
						elseif isElementInWater(v) then
							local index = getShamalInteriorByElement(v)
							if index then
								killPlayersInShamalInterior(shamal_interiors[index]["dimension"], true)
							end
						elseif not getShamalInteriorByElement(v) then
							createShamalInteriorForElement(v)
						end
					else
						removeElementShamalInterior(v)
					end
				end
			end
		end
		local index = 1
		while true do
			if index > #shamal_interiors then
				break
			end
			if not isElement(shamal_interiors[index]["element"]) then
				killPlayersInShamalInterior(shamal_interiors[index]["dimension"])
				table.remove(shamal_interiors, index)
				index = 1
			else
				index = index + 1
			end
		end
		index = 1
		while true do
			if index > #vehiclesToDestroy then
				break
			end
			if isElement(vehiclesToDestroy[index]) then
				destroyElement(vehiclesToDestroy[index])
				vehiclesToDestroy[index] = nil
			end
			table.remove(vehiclesToDestroy, index)
			index = 1
		end
	end
, 1000, 0)

addEventHandler("onElementDestroy", getRootElement(),
	function()
		source = nil
	end
)
