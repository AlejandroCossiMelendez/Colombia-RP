local shamal_interior_collision = createColSphere(1.74491, 28.27952, 1199.59375, 50)
local shamal_door = createObject(2924, 2.45847, 34.53856, 1199.84375, 0, 0, 0)
setObjectScale(shamal_door, 1.125)
setElementInterior(shamal_door, 1)
setElementDimension(shamal_door, 1)

function isPlayerInShamal()
	local ply = getLocalPlayer()
	if not isElement(ply) then
		return false
	end
	if getElementInterior(ply) ~= 1 then
		return false
	end
	if getElementDimension(ply) == 0 then
		return false
	end
	if not isElementWithinColShape(ply, shamal_interior_collision) then
		return false
	end
	return true
end

addEventHandler("onClientProjectileCreation", getRootElement(),
	function(creator)
		if creator ~= getLocalPlayer() then
			return
		end
		if not isPlayerInShamal() then
			return
		end
		triggerServerEvent("onPlayerFireInShamal", creator)
	end
)

function isObjectOrNothing(element)
	if not isElement(element) then
		return true
	end
	if getElementType(element) == "object" then
		return true
	end
	return false
end

addEventHandler("onClientPlayerWeaponFire", getLocalPlayer(),
	function(weapon, ammo, ammoInClip, hitX, hitY, hitZ, hitElement)
		if not isPlayerInShamal() then
			return
		end
		if not isObjectOrNothing(hitElement) then
			return
		end
		triggerServerEvent("onPlayerFireInShamal", source)
	end
)

setTimer(
	function()
		if isPlayerInShamal() then
			setElementDimension(shamal_door, getElementDimension(getLocalPlayer()))
		end
	end
, 1000, 0)
		

local f_should_be_bound = true
local g_should_be_bound = true

function isVehicle(element)
	if not isElement(element) then
		return false
	end
	if getElementType(element) ~= "vehicle" then
		return false
	end
	return true
end

function isVehicleBlownOrExploding(element)
	if not isElement(element) then
		return false
	end
	if not isVehicle(element) then
		return false
	end
	if not isVehicleBlown(element) and getElementHealth(element) > 200 and not (isElementInWater(element)) then
		return false
	end
	return true
end

function isVehicleShamal(element)
	if not isElement(element) then
		return false
	end
	local model = getElementModel(element)
	if model ~= 519 then
		return false
	end
	return true
end

function enterShamalFunc()
	g_should_be_bound = false
	unbindKey("g", "down", enterShamalFunc)
	setTimer(
		function()
			g_should_be_bound = true
			bindKey("g", "down", enterShamalFunc)
		end
	, 1500, 1)

	local ply = getLocalPlayer()
	if not ply then
		return
	end
	if isPedInVehicle(ply) then
		return
	end
	
	local x, y, z = getElementPosition(getLocalPlayer())
	local mindist = 5
	local closer = false
	local vehicles = getElementsByType("vehicle")
	for i, v in pairs(vehicles) do
		if isVehicleShamal(v) then
			if not isVehicleBlownOrExploding(v) then
				local vx, vy, vz = getElementPosition(v)
				local dist = getDistanceBetweenPoints3D(vx, vy, vz, x, y, z)
				if dist <= mindist then
					mindist = dist
					closer = v
				end
			end
		end
	end
	
	if not closer then
		return
	end
	
	triggerServerEvent("onPlayerShamalEnterRequest", getLocalPlayer(), closer)
end

function exitShamalFunc()
	f_should_be_bound = false
	unbindKey("enter_exit", "down", exitShamalFunc)
	setTimer(
		function()
			f_should_be_bound = true
			bindKey("enter_exit", "down", exitShamalFunc)
		end
	, 1500, 1)
	
	if not isPlayerInShamal() then
		return
	end
	local dim = getElementDimension(getLocalPlayer())
	
	triggerServerEvent("onPlayerShamalExitRequest", getLocalPlayer())
end


bindKey("g", "down", enterShamalFunc)
bindKey("enter_exit", "down", exitShamalFunc)

setTimer(
	function()
		if not (getKeyBoundToFunction(enterShamalFunc)) and g_should_be_bound then
			bindKey("g", "down", enterShamalFunc)
		end
		if not (getKeyBoundToFunction(exitShamalFunc)) and f_should_be_bound then
			bindKey("enter_exit", "down", exitShamalFunc)
		end
	end
, 1000, 0)

addEvent("onShamalExplosionRequest", true)
addEventHandler("onShamalExplosionRequest", getLocalPlayer(),
	function()
		createExplosion(1.55073, 27.78932, 1199.59375, 10, true, 2.0, false)
	end
)
