addEventHandler('onClientResourceStart', resourceRoot, 
function() 

palmtxd = engineLoadTXD("textures/gta_tree_palm.txd")
engineImportTXD(palmtxd, 622)

palm03 = engineLoadDFF('textures/veg_palm03.dff', 622) 
engineReplaceModel(palm03, 622)

palm02 = engineLoadDFF('textures/veg_palm02.dff', 621) 
engineReplaceModel(palm02, 621)  
end 
)





