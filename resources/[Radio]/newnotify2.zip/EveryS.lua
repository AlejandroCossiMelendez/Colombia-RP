function displayServerNotificacao(source, message, type)
	triggerClientEvent(source, "serverNotifys2", getRootElement(), message, type)
end
addEvent("NotifyENVR", true)
addEventHandler("NotifyENVR", getRootElement(), displayServerNotificacao)