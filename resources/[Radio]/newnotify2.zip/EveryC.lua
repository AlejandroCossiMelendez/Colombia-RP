local screenW, screenH = guiGetScreenSize()
local x, y = (screenW/1366), (screenH/768)

Vars = {}
Vars["font"] = dxCreateFont("img/HelveticaNeue.ttf", 9)

Notifys = {}

function dxDrawDownload()
    for i, v in ipairs(Notifys) do
        if (i > 6) then 
            return
        end
        local posX 
        local posY 
        if (v[3] < getTickCount()-10000) then
            Notifys[i][8] = v[8] - 2
            if (v[8] <= 2) then
                table.remove(Notifys, i)
            end
        elseif (v[8] <= 248) then
            Notifys[i][8] = v[8] + 2
        end
        if (i == 1) then
            if (#Notifys >= 2) then
                posX = 1150 - (Notifys[2][4] + v[4] + 50)
            else
                posX = 1150 - v[4]
            end
            posY = 20
        elseif (i == 2) then
            posX = 1150 - v[4]
            posY = 20
        elseif (i == 3) then
            if (#Notifys >= 4) then
                posX = 1150 - (Notifys[4][4] + v[4] + 50)
            else
                posX = 1150 - v[4]
            end
            posY = 60
        elseif (i == 4) then
            posX = 1150 - v[4]
            posY = 60
        elseif (i == 5) then
            if (#Notifys >= 6) then
                posX = 1150 - (Notifys[6][4] + v[4] + 50)
            else
                posX = 1150 - v[4]
            end
            posY = 100
        elseif (i == 6) then
            posX = 1150 - v[4]
            posY = 100
        end
        dxDrawImage(x*posX, y*posY, x*(v[4]+40), y*27, "img/bar.png", 0, 0, 0, tocolor(v[5], v[6], v[7], v[8]), true)
        dxDrawImage(x*(posX+3), y*(posY+4.2), x*19, y*19, "img/"..v[2]..".png", 0, 0, 0, tocolor(255, 255, 255, v[8]), true)
        dxDrawText(v[1], x*(posX+25), y*(posY+5), x*(v[4] - 15), y*27, tocolor(255, 255, 255, v[8]), x*1, "arial", "left", "top", false, false, true, false, false)
    end
end
addEventHandler("onClientRender", getRootElement(), dxDrawDownload)

function addNotify(message, tyype)
    local tyype = "info"
    local r, g, b
    if (tyype == "sucess") then
        r, g, b = 49,185,52
    elseif (tyype == "error") then
        r, g, b = 231,43,44
    else
        r, g, b = 231,180,44
    end
    table.insert(Notifys, {message, tyype, getTickCount(), dxGetTextWidth(message, 1, Vars["font"]), r, g, b, 0})
end
addEvent("serverNotifys2", true)
addEventHandler("serverNotifys2", getRootElement(), addNotify)

--[[function dxDrawDownload2()
    if (Vars["rot"] < 360) then
        Vars["rot"] = Vars["rot"] + 5
    else
        Vars["rot"] = 0 
    end
    if (Vars["alpha2"] >= 255) then
        if (Vars["transition"]) then
            if (Vars["transition"] == "DESC") then
                if (Vars["alpha"] > 2) then
                    Vars["alpha"] = Vars["alpha"] - 2
                else
                    Vars["transition"] = "ASC"
                    if (Vars["n"] >= 3) then
                        Vars["n"] = 1
                    else
                        Vars["n"] = Vars["n"] + 1
                    end
                end
            else
                if (Vars["alpha"] < 253) then
                    Vars["alpha"] = Vars["alpha"] + 2
                else
                    Vars["transition"] = false
                end
            end
        end
    else
        if (Vars["alpha2"] > 2) then
            Vars["alpha2"] = Vars["alpha2"] - 2
        else
            removeEventHandler("onClientRender", getRootElement(), dxDrawDownload)
            removeEventHandler("onClientPreRender", getRootElement(), dxDrawDownload2)
            Vars = nil
        end
    end
end
addEventHandler("onClientPreRender", getRootElement(), dxDrawDownload2)

function TerminateDraw()
    if isTimer(Vars["timer"]) then
        killTimer(Vars["timer"])
    end
    Vars["alpha2"] = 254
end--]]

function apagarScript()
    if fileExists("client.lua") then
        fileDelete("client.lua")
    end
end
addEventHandler("onClientResourceStart", getResourceRootElement(getThisResource()), apagarScript)
addEventHandler("onClientPlayerQuit", getRootElement(), apagarScript)
addEventHandler("onClientPlayerJoin", getRootElement(), apagarScript)